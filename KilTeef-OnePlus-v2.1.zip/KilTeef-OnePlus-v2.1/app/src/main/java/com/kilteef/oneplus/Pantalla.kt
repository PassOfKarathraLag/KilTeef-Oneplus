package com.kilteef.oneplus

import android.app.Activity
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

// ---------- 5. Pantalla / línea verde ----------

@Composable
fun Pantalla(onTest: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Línea verde en la pantalla", style = MaterialTheme.typography.headlineSmall)
        Info(
            "Lo que sí y lo que no",
            "Una app no puede reparar una línea verde: casi siempre es el panel AMOLED o su conexión (hardware). Sí puedo ayudarte a comprobarlo y a documentarlo."
        )
        Btn("▶ Iniciar prueba de colores a pantalla completa") { onTest() }
        Info(
            "Cómo interpretar el resultado",
            "1) Con la línea visible, toma una captura de pantalla.\n" +
                "2) Si la línea NO sale en la captura → es hardware (panel).\n" +
                "3) Si SÍ sale en la captura → puede ser software: actualiza OxygenOS, haz copia de seguridad y prueba un restablecimiento.\n" +
                "4) Anota si aparece con calor, brillo bajo/alto o 60/120 Hz: sirve para soporte."
        )
        Info(
            "Garantía",
            "OnePlus anunció garantía de por vida de pantalla para la línea verde (diciembre 2024). La cobertura depende del país de compra: confirma en un centro de servicio OnePlus en México."
        )
        Btn("Ajustes de pantalla (60/120 Hz)") { go(ctx, Settings.ACTION_DISPLAY_SETTINGS) }
    }
}

@Composable
fun ScreenTest(onExit: () -> Unit) {
    val colors = listOf(Color.Black, Color.White, Color.Red, Color.Green, Color.Blue, Color.Gray)
    var i by remember { mutableIntStateOf(0) }
    val view = LocalView.current
    DisposableEffect(Unit) {
        val c = WindowCompat.getInsetsController((view.context as Activity).window, view)
        c.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { c.show(WindowInsetsCompat.Type.systemBars()) }
    }
    val bg = colors[i]
    Box(
        Modifier.fillMaxSize().background(bg).pointerInput(Unit) {
            detectTapGestures { if (i < colors.lastIndex) i++ else onExit() }
        },
        contentAlignment = Alignment.BottomCenter
    ) {
        Text(
            "Toca para cambiar de color (${i + 1}/${colors.size}) · al final sales",
            color = if (bg == Color.White) Color.Black else Color.White,
            fontSize = 12.sp, modifier = Modifier.padding(24.dp)
        )
    }
}
