package com.kilteef.oneplus

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun Mas(onTest: () -> Unit) {
    var sec by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp, 12.dp, 16.dp, 0.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (sec == 0) Button({ sec = 0 }, Modifier.weight(1f)) { Text("🚀 Avanzado") }
            else OutlinedButton({ sec = 0 }, Modifier.weight(1f)) { Text("🚀 Avanzado") }
            if (sec == 1) Button({ sec = 1 }, Modifier.weight(1f)) { Text("📱 Pantalla") }
            else OutlinedButton({ sec = 1 }, Modifier.weight(1f)) { Text("📱 Pantalla") }
        }
        Box(Modifier.weight(1f)) {
            if (sec == 0) Avanzado() else Pantalla(onTest)
        }
    }
}
