package com.kilteef.oneplus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thumbs.ctx = applicationContext
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

val TABS = listOf(
    "🏠" to "Inicio", "⚙️" to "CPU", "📋" to "Apps",
    "🧹" to "Limpieza", "🔒" to "Privacidad", "🛠" to "Más"
)

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var testing by remember { mutableStateOf(false) }
    var shiz by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<AppRow>?>(null) }
    val reload: () -> Unit = {
        scope.launch {
            apps = null
            apps = withContext(Dispatchers.IO) { loadApps(ctx) }
        }
    }
    LaunchedEffect(Unit) { reload() }
    LaunchedEffect(Unit) {
        while (true) {
            shiz = withContext(Dispatchers.IO) { Sh.granted() }
            delay(2000)
        }
    }

    CompositionLocalProvider(LocalShiz provides shiz) {
        if (testing) {
            ScreenTest { testing = false }
        } else {
            Scaffold(bottomBar = {
                NavigationBar {
                    TABS.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Text(t.first) },
                            label = { Text(t.second, fontSize = 10.sp, maxLines = 1) }
                        )
                    }
                }
            }) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    Crossfade(tab, animationSpec = tween(300), label = "tab") { t ->
                        when (t) {
                            0 -> Inicio(apps) { tab = it }
                            1 -> Cpu()
                            2 -> Procesos(apps, reload)
                            3 -> Limpieza(apps, reload)
                            4 -> Privacidad()
                            else -> Mas { testing = true }
                        }
                    }
                }
            }
        }
    }
}
