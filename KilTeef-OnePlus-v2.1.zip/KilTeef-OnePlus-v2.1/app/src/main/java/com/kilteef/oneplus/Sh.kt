package com.kilteef.oneplus

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/** Acceso tipo ADB (sin root) mediante Shizuku. Si no está activo, todo devuelve un aviso. */
object Sh {
    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun ask() {
        try { Shizuku.requestPermission(77) } catch (e: Throwable) { }
    }

    fun run(cmd: String): String {
        if (!granted()) return "Shizuku no está activo"
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (e: Throwable) {
            "Error: " + (e.cause?.message ?: e.message)
        }
    }

    suspend fun runIO(cmd: String): String = withContext(Dispatchers.IO) { run(cmd) }
}

data class CpuProc(val name: String, val pct: Float)
data class Temp(val name: String, val c: Float, val type: Int)
data class Access(val pkg: String, val op: String, val agoSec: Long)

fun parseCpu(out: String): List<CpuProc> {
    val r = Regex("""^\s*[+-]?([\d.]+)%\s+\d+/([^:]+):""", RegexOption.MULTILINE)
    return r.findAll(out)
        .map { CpuProc(it.groupValues[2].trim(), it.groupValues[1].toFloatOrNull() ?: 0f) }
        .sortedByDescending { it.pct }.take(15).toList()
}

fun parseTemps(out: String): List<Temp> {
    val sec = out.substringAfter("Current temperatures from HAL:", out).substringBefore("Current cooling devices from HAL:")
    val r = Regex("""Temperature\{mValue=([-\d.]+), mType=(\d+), mName=([^,}]+)""")
    return r.findAll(sec)
        .map { Temp(it.groupValues[3].trim(), it.groupValues[1].toFloatOrNull() ?: 0f, it.groupValues[2].toIntOrNull() ?: -1) }
        .filter { it.c > -50f && it.c < 150f }.distinctBy { it.name }.toList()
}

fun parseServices(out: String): List<Pair<String, Int>> {
    val r = Regex("""\*\s+ServiceRecord\{[0-9a-f]+ u\d+ ([\w.]+)/""")
    return r.findAll(out).map { it.groupValues[1] }.groupingBy { it }.eachCount()
        .toList().sortedByDescending { it.second }.take(30)
}

fun parseAgo(s: String): Long {
    var t = 0.0
    Regex("""(\d+)(ms|d|h|m|s)""").findAll(s).forEach {
        val n = it.groupValues[1].toDouble()
        t += when (it.groupValues[2]) {
            "d" -> n * 86400
            "h" -> n * 3600
            "m" -> n * 60
            "s" -> n
            else -> n / 1000
        }
    }
    return t.toLong()
}

/** Último acceso a cámara/micrófono por app, leído de AppOps (requiere Shizuku). */
fun accessHistory(pkgs: List<String>): List<Access> {
    val out = ArrayList<Access>()
    for (p in pkgs) {
        val r = Sh.run("cmd appops get $p | grep -E '^(CAMERA|RECORD_AUDIO)'")
        for (line in r.lines()) {
            val op = line.substringBefore(':').trim()
            val ago = Regex("""time=\+?(\S+) ago""").find(line)?.groupValues?.get(1) ?: continue
            out.add(Access(p, op, parseAgo(ago)))
        }
    }
    return out.sortedBy { it.agoSec }
}
