package com.kilteef.oneplus

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

@Composable
fun Avanzado() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shiz = LocalShiz.current
    var alive by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var cmd by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var top by remember { mutableStateOf<List<CpuProc>?>(null) }
    var temps by remember { mutableStateOf<List<Temp>?>(null) }
    var svcs by remember { mutableStateOf<List<Pair<String, Int>>?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            alive = withContext(Dispatchers.IO) { Sh.alive() }
            delay(1500)
        }
    }

    fun exec(c: String, done: (String) -> Unit) {
        if (busy) return
        busy = true
        scope.launch {
            val r = Sh.runIO(c)
            done(r)
            busy = false
        }
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Funciones avanzadas (sin root)", style = MaterialTheme.typography.headlineSmall)
        Appear(0) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Pulse(if (shiz) Color(0xFF66BB6A) else if (alive) Color(0xFFFFCA28) else Color(0xFF9E9E9E))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            if (shiz) "Shizuku: LISTO ✅" else if (alive) "Shizuku activo · falta dar permiso" else "Shizuku apagado o no instalado",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    if (!shiz) {
                        Text(
                            "Shizuku es una app gratuita que presta a KilTeef permisos de ADB (como conectar el teléfono a una PC) sin root. Pasos:\n" +
                                "1) Instala Shizuku.\n" +
                                "2) Ajustes → Acerca del teléfono → toca 7 veces 'Número de compilación'.\n" +
                                "3) Opciones de desarrollador → activa 'Depuración inalámbrica' y empareja desde Shizuku.\n" +
                                "4) En Shizuku toca 'Iniciar'.\n" +
                                "5) Vuelve aquí y toca 'Dar permiso'.\n" +
                                "Después de cada reinicio del teléfono hay que repetir el paso 4.",
                            fontSize = 12.sp
                        )
                        if (!alive) {
                            Btn("Descargar Shizuku (Google Play)") {
                                tryStart(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api")))
                            }
                            Btn("Abrir Shizuku") {
                                val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                                if (i == null || !tryStart(ctx, i)) toast(ctx, "Shizuku no está instalado")
                            }
                        } else {
                            Btn("Dar permiso a KilTeef") { Sh.ask() }
                        }
                    }
                }
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (!shiz) Text("Las herramientas de abajo se activan cuando Shizuku esté listo.", fontSize = 12.sp)

        Text("Herramientas", style = MaterialTheme.typography.titleMedium)
        Btn("🧹 Limpiar caché de TODAS las apps", enabled = shiz && !busy) {
            val before = snap(ctx).stoUsedGb
            exec("pm trim-caches 999G") {
                toast(ctx, "Caché limpiada · liberado ≈ %.2f GB".format(maxOf(0f, before - snap(ctx).stoUsedGb)))
            }
        }
        Btn("⚙️ Optimizar apps en segundo plano (ART)", enabled = shiz && !busy) {
            exec("cmd package bg-dexopt-job") { toast(ctx, "Optimización iniciada; el sistema la termina solo") }
        }
        Btn("📊 Procesos con más CPU (real)", enabled = shiz && !busy) {
            exec("dumpsys cpuinfo") { top = parseCpu(it) }
        }
        top?.let { l ->
            if (l.isEmpty()) Text("Sin datos: el formato de esta versión de Android es distinto.", fontSize = 12.sp)
            val mx = (l.maxOfOrNull { it.pct } ?: 1f).coerceAtLeast(1f)
            l.forEach { p ->
                Column {
                    Text("${labelOf(ctx, p.name)} · %.1f %%".format(p.pct), fontSize = 12.sp)
                    AnimBar(p.pct / mx)
                }
            }
        }
        Btn("🌡 Temperaturas internas (CPU, GPU, piel)", enabled = shiz && !busy) {
            exec("dumpsys thermalservice") { temps = parseTemps(it) }
        }
        temps?.let { l ->
            if (l.isEmpty()) Text("Sin datos de sensores.", fontSize = 12.sp)
            l.forEach { Text("${it.name}: %.1f °C".format(it.c), fontSize = 13.sp) }
        }
        Btn("🧩 Servicios en ejecución por app", enabled = shiz && !busy) {
            exec("dumpsys activity services") { svcs = parseServices(it) }
        }
        svcs?.let { l ->
            if (l.isEmpty()) Text("Sin datos.", fontSize = 12.sp)
            l.forEach { Text("${labelOf(ctx, it.first)} · ${it.second} servicio(s)", fontSize = 13.sp) }
        }

        Text("Animaciones del sistema", style = MaterialTheme.typography.titleMedium)
        Text("Reducirlas hace que el teléfono se sienta más rápido.", fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Apagar" to "0", "Rápidas" to "0.5", "Normal" to "1").forEach { (n, v) ->
                OutlinedButton(
                    {
                        exec("settings put global window_animation_scale $v; settings put global transition_animation_scale $v; settings put global animator_duration_scale $v") {
                            toast(ctx, "Animaciones: $n")
                        }
                    },
                    Modifier.weight(1f), enabled = shiz && !busy, contentPadding = PaddingValues(4.dp)
                ) { Text(n, fontSize = 12.sp) }
            }
        }

        Text("Consola (comandos de shell)", style = MaterialTheme.typography.titleMedium)
        Text("Corre con permisos de ADB. No pegues comandos de fuentes que no conozcas.", fontSize = 11.sp)
        OutlinedTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), label = { Text("Ej: dumpsys battery") }, singleLine = true)
        Btn("▶ Ejecutar", enabled = shiz && !busy && cmd.isNotBlank()) {
            exec(cmd) { out = it.takeLast(4000) }
        }
        if (out.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Text(out, Modifier.padding(10.dp), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
