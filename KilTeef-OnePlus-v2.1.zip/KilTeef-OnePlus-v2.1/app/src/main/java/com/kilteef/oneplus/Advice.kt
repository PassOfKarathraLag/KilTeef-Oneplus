package com.kilteef.oneplus

import android.content.Context
import android.os.Environment

data class Tip(val icon: String, val title: String, val text: String, val level: Int, val tab: Int)

/** Calcula la "salud" (0-100) y una lista de sugerencias. tab: 1 CPU, 2 Apps, 3 Limpieza, 4 Privacidad, 5 Más. */
fun advise(ctx: Context, s: Snap, apps: List<AppRow>?, shiz: Boolean): Pair<Int, List<Tip>> {
    var score = 100
    val t = ArrayList<Tip>()
    val ramPct = (s.ramUsedMb * 100 / s.ramTotalMb.coerceAtLeast(1)).toInt()
    val stoPct = (s.stoUsedGb * 100 / s.stoTotalGb.coerceAtLeast(1f)).toInt()
    val tt = "%.0f".format(s.temp)

    if (s.temp >= 43) {
        score -= 25
        t.add(Tip("🔥", "Temperatura alta ($tt °C)", "Deja de usarlo un rato, quita la funda y no cargues. Mira el plan de enfriamiento.", 2, 1))
    } else if (s.temp >= 40) {
        score -= 12
        t.add(Tip("🌡", "Está caliente ($tt °C)", "Baja el brillo, pon 60 Hz y cierra apps pesadas.", 1, 1))
    }
    if (s.charging && s.temp >= 38) {
        t.add(Tip("⚡", "Cargando y tibio", "Cargar con calor desgasta la batería: desconéctalo o no lo uses mientras carga.", 1, 1))
    }
    if (s.thermal >= 2) {
        score -= 15
        t.add(Tip("🛑", "El sistema está limitando el rendimiento", "Estado térmico: ${thermalName(s.thermal)}. Déjalo enfriar.", 2, 1))
    }
    if (ramPct >= 85) {
        score -= 15
        t.add(Tip("🧠", "RAM casi llena ($ramPct %)", "Toca 'Optimizar ahora' en Inicio o 'Liberar RAM' en Limpieza.", 2, 3))
    } else if (ramPct >= 75) {
        score -= 7
        t.add(Tip("🧠", "RAM alta ($ramPct %)", "Cierra apps que no uses o libera RAM.", 1, 3))
    }
    if (stoPct >= 90) {
        score -= 20
        t.add(Tip("💾", "Almacenamiento casi lleno ($stoPct %)", "Escanea archivos grandes, duplicados y APK viejos en Limpieza.", 2, 3))
    } else if (stoPct >= 80) {
        score -= 10
        t.add(Tip("💾", "Almacenamiento al $stoPct %", "Conviene limpiar archivos grandes y duplicados.", 1, 3))
    }
    if (s.uptimeH > 168) {
        score -= 10
        t.add(Tip("🔄", "Llevas más de 7 días sin reiniciar", "Reiniciar libera memoria y procesos pegados.", 1, 0))
    } else if (s.uptimeH > 72) {
        score -= 5
        t.add(Tip("🔄", "Llevas más de 3 días sin reiniciar", "Un reinicio semanal mantiene el teléfono fluido.", 0, 0))
    }
    if (s.health == 3 || s.health == 5 || s.health == 6) {
        score -= 10
        t.add(Tip("🔋", "La batería reporta un problema", "Si se repite, llévala a servicio técnico.", 2, 0))
    }
    if (s.cycles >= 800) {
        score -= 5
        t.add(Tip("🔋", "Batería con ${s.cycles} ciclos de carga", "Es normal que la autonomía baje; considera cambiarla si te falla el día.", 1, 0))
    }
    if (apps != null) {
        val fgs = apps.count { !it.system && it.fgsOn }
        if (fgs >= 6) {
            score -= 8
            t.add(Tip("📋", "$fgs apps con servicios activos", "Revisa la pestaña Apps y detén o restringe las que no uses.", 1, 2))
        } else if (fgs >= 3) {
            score -= 4
            t.add(Tip("📋", "$fgs apps con servicios activos", "Mira cuáles son en la pestaña Apps.", 0, 2))
        }
        val unused = apps.count { a ->
            val x = maxOf(a.last, a.lastAny)
            !a.system && (x == 0L || System.currentTimeMillis() - x > 30L * 86400_000)
        }
        if (unused >= 10) {
            score -= 5
            t.add(Tip("🗑", "$unused apps sin usar en 30+ días", "Desinstalarlas libera espacio y quita procesos.", 1, 3))
        }
    }
    if (!hasUsage(ctx)) t.add(Tip("🔑", "Falta el 'Acceso de uso'", "Sin él no puedo ver qué apps están activas. Se da en la pestaña Apps.", 1, 2))
    if (!Environment.isExternalStorageManager()) t.add(Tip("📂", "Falta 'Acceso a todos los archivos'", "Necesario para escanear y limpiar. Se da en Limpieza.", 1, 3))
    if (!GuardService.running.value) t.add(Tip("🛡", "El vigilante de cámara/micrófono está apagado", "Enciéndelo en Privacidad para recibir avisos.", 0, 4))
    if (!shiz) t.add(Tip("🚀", "Activa Shizuku para funciones avanzadas", "CPU real por app, limpiar caché de todas, quitar permisos al instante y más. Sin root.", 0, 5))
    if (t.none { it.level > 0 }) t.add(Tip("✅", "Todo en orden", "No veo problemas ahora mismo. Vuelve a revisar de vez en cuando.", 0, 0))
    return Pair(score.coerceIn(0, 100), t.sortedByDescending { it.level })
}
