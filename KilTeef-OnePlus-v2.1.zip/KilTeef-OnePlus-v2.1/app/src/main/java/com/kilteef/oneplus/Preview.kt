package com.kilteef.oneplus

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.util.LruCache
import android.util.Size
import android.webkit.MimeTypeMap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

/** Miniaturas de imágenes, videos y APK con caché en memoria. */
object Thumbs {
    var ctx: Context? = null
    private val cache = LruCache<String, Bitmap>(80)

    fun get(path: String, px: Int): Bitmap? {
        val key = "$path@$px"
        cache.get(key)?.let { return it }
        val f = File(path)
        val bmp: Bitmap? = try {
            when (catOf(f.name)) {
                "Videos" -> ThumbnailUtils.createVideoThumbnail(f, Size(px, px), null)
                "Imágenes" -> ThumbnailUtils.createImageThumbnail(f, Size(px, px), null)
                "APK" -> apkIcon(f, px)
                else -> null
            }
        } catch (e: Exception) { null }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    private fun apkIcon(f: File, px: Int): Bitmap? {
        val pm = ctx?.packageManager ?: return null
        val pi = pm.getPackageArchiveInfo(f.path, PackageManager.PackageInfoFlags.of(0)) ?: return null
        val ai = pi.applicationInfo ?: return null
        ai.sourceDir = f.path
        ai.publicSourceDir = f.path
        return ai.loadIcon(pm).toBitmap(px, px)
    }
}

data class PreviewData(val bmp: Bitmap?, val lines: List<String>)

fun buildPreview(ctx: Context, path: String): PreviewData {
    val f = File(path)
    val lines = ArrayList<String>()
    val date = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(f.lastModified()))
    lines.add("Modificado: $date")
    lines.add("Ruta: ${f.parent}")
    val cat = catOf(f.name)
    try {
        when (cat) {
            "Videos", "Audio" -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(path)
                    val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                    if (ms != null) lines.add("Duración: ${ms / 60000}:" + "%02d".format(ms / 1000 % 60))
                    if (cat == "Videos") {
                        val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                        val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                        if (w != null && h != null) lines.add("Resolución: ${w}x$h")
                    } else {
                        val title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                        val artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                        if (title != null) lines.add("Título: $title")
                        if (artist != null) lines.add("Artista: $artist")
                    }
                } finally {
                    r.release()
                }
            }
            "Imágenes" -> {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(path, o)
                lines.add("Resolución: ${o.outWidth}x${o.outHeight}")
            }
            "APK" -> {
                val pm = ctx.packageManager
                val pi = pm.getPackageArchiveInfo(path, PackageManager.PackageInfoFlags.of(0))
                val ai = pi?.applicationInfo
                if (pi != null && ai != null) {
                    ai.sourceDir = path
                    ai.publicSourceDir = path
                    lines.add("App: ${pm.getApplicationLabel(ai)}")
                    lines.add("Paquete: ${pi.packageName}")
                    lines.add("Versión: ${pi.versionName}")
                }
            }
            "Comprimidos" -> {
                if (f.extension.lowercase() == "zip") {
                    ZipFile(f).use { z ->
                        lines.add("Contiene ${z.size()} archivos")
                        z.entries().asSequence().take(8).forEach { lines.add("  • ${it.name}") }
                    }
                }
            }
            else -> {
                if (f.extension.lowercase() in setOf("txt", "log", "csv", "json", "xml", "md", "ini", "html")) {
                    lines.add("— Inicio del archivo —")
                    f.bufferedReader().useLines { seq -> seq.take(12).forEach { lines.add(it.take(120)) } }
                }
            }
        }
    } catch (e: Exception) {
        lines.add("(No se pudo leer más detalles)")
    }
    val big = if (cat == "Videos" || cat == "Imágenes" || cat == "APK") Thumbs.get(path, 720) else null
    return PreviewData(big, lines)
}

fun openFile(ctx: Context, path: String) {
    try {
        val f = File(path)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (!tryStart(ctx, i)) toast(ctx, "No hay app para abrir este archivo")
    } catch (e: Exception) {
        toast(ctx, "No se pudo abrir el archivo")
    }
}

@Composable
fun FileThumb(path: String, size: Dp = 56.dp, px: Int = 160) {
    val bmp by produceState<Bitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { Thumbs.get(path, px) }
    }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(8.dp)).background(Color(0x22FFFFFF)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(iconOf(catOf(File(path).name)), fontSize = 22.sp)
        }
    }
}

@Composable
fun PreviewDialog(f: FileRow, selected: Boolean, onToggle: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val data by produceState<PreviewData?>(null, f.path) {
        value = withContext(Dispatchers.IO) { buildPreview(ctx, f.path) }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(File(f.path).name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 16.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                val d = data
                if (d == null) {
                    CircularProgressIndicator()
                } else {
                    val b = d.bmp
                    if (b != null) {
                        Image(b.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 280.dp), contentScale = ContentScale.Fit)
                        Spacer(Modifier.height(8.dp))
                    }
                    Text("${f.kind} · ${fmt(f.bytes)}", style = MaterialTheme.typography.labelLarge)
                    d.lines.forEach { Text(it, fontSize = 12.sp) }
                }
            }
        },
        confirmButton = { TextButton({ openFile(ctx, f.path) }) { Text("Abrir") } },
        dismissButton = {
            Row {
                TextButton(onToggle) { Text(if (selected) "Quitar selección" else "Seleccionar para borrar") }
                TextButton(onClose) { Text("Cerrar") }
            }
        }
    )
}
