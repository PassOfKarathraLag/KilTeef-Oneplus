package com.kilteef.oneplus

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** true cuando Shizuku está activo y KilTeef tiene permiso. */
val LocalShiz = compositionLocalOf { false }

/** Estado que sobrevive al cambiar de pestaña. */
object Store {
    var scan by mutableStateOf<ScanResult?>(null)
}

@Composable
fun Appear(i: Int = 0, content: @Composable () -> Unit) {
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(50L * i.coerceAtMost(10))
        v = true
    }
    AnimatedVisibility(v, enter = fadeIn(tween(450)) + slideInVertically { it / 5 }) { content() }
}

@Composable
fun AnimBar(p: Float, modifier: Modifier = Modifier.fillMaxWidth(), color: Color = MaterialTheme.colorScheme.primary) {
    val a by animateFloatAsState(p.coerceIn(0f, 1f), tween(600), label = "bar")
    LinearProgressIndicator(progress = { a }, modifier = modifier, color = color)
}

@Composable
fun Pulse(color: Color, size: Int = 12) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable<Float>(tween<Float>(900), RepeatMode.Reverse), label = "alpha")
    Box(Modifier.size(size.dp).alpha(a).background(color, CircleShape))
}

@Composable
fun Info(title: String, body: String, color: Color = Color.Unspecified) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(body, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }
}

@Composable
fun Btn(text: String, enabled: Boolean = true, onClick: () -> Unit) =
    OutlinedButton(onClick, Modifier.fillMaxWidth(), enabled = enabled) { Text(text) }

@Composable
fun Title(text: String) =
    Text(text, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp))

fun tempLabel(t: Float) = when {
    t < 35 -> "Normal"
    t < 40 -> "Tibia"
    t < 43 -> "Caliente"
    else -> "Muy caliente"
}

fun tempColor(t: Float) = when {
    t < 40 -> Color(0xFF66BB6A)
    t < 43 -> Color(0xFFFFCA28)
    else -> Color(0xFFEF5350)
}

fun push(l: MutableList<Float>, v: Float) {
    l.add(v)
    if (l.size > 90) l.removeAt(0)
}

@Composable
fun Chart(h: List<Float>, color: Color) {
    Card(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(100.dp).padding(12.dp)) {
            if (h.size < 2) return@Canvas
            val lo = h.min() - 1f
            val hi = h.max() + 1f
            val path = Path()
            h.forEachIndexed { i, v ->
                val x = size.width * i / (h.size - 1)
                val y = size.height * (1f - (v - lo) / (hi - lo))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(width = 4f))
        }
    }
}

@Composable
fun AppCard(a: AppRow) {
    val ctx = LocalContext.current
    val shiz = LocalShiz.current
    val scope = rememberCoroutineScope()
    val pad = PaddingValues(horizontal = 6.dp)
    Appear {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text(a.name, style = MaterialTheme.typography.titleSmall)
                Text(a.pkg, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "Uso 24 h: ${a.fgMin} min · último uso: ${ago(maxOf(a.last, a.lastAny))}" +
                        (if (a.fgs > 0) " · servicios 1er plano: ${a.fgs}" else "") +
                        " · ${a.totalMb} MB (caché ${a.cacheMb} MB)",
                    fontSize = 12.sp
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton({
                        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(a.pkg)
                        toast(ctx, "Orden enviada a ${a.name}")
                    }, contentPadding = pad) { Text("Detener", fontSize = 13.sp) }
                    TextButton({ go(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, a.pkg) }, contentPadding = pad) { Text("Info", fontSize = 13.sp) }
                    TextButton({ openPerms(ctx, a.pkg) }, contentPadding = pad) { Text("Permisos", fontSize = 13.sp) }
                    if (!a.system) TextButton({ go(ctx, Intent.ACTION_DELETE, a.pkg) }, contentPadding = pad) { Text("Desinstalar", fontSize = 13.sp) }
                }
                if (shiz) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton({
                            scope.launch { toast(ctx, "${a.name}: " + Sh.runIO("am force-stop ${a.pkg}").ifBlank { "detenida" }.take(80)) }
                        }, contentPadding = pad) { Text("⛔ Parar", fontSize = 13.sp) }
                        TextButton({
                            scope.launch {
                                Sh.runIO("cmd appops set ${a.pkg} RUN_ANY_IN_BACKGROUND ignore; am set-standby-bucket ${a.pkg} restricted")
                                toast(ctx, "${a.name}: restringida en segundo plano")
                            }
                        }, contentPadding = pad) { Text("🔒 Restringir 2º plano", fontSize = 13.sp) }
                        TextButton({
                            scope.launch { toast(ctx, "${a.name}: " + Sh.runIO("pm clear --cache-only ${a.pkg}").take(80)) }
                        }, contentPadding = pad) { Text("🧹 Caché", fontSize = 13.sp) }
                    }
                }
            }
        }
    }
}
