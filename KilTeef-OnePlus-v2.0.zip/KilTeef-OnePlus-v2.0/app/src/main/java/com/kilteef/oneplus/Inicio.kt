package com.kilteef.oneplus

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun healthText(h: Int) = when (h) {
    2 -> "Buena"
    3 -> "Sobrecalentada"
    4 -> "Muerta"
    5 -> "Sobrevoltaje"
    6 -> "Falla"
    7 -> "Fría"
    else -> "Desconocida"
}

@Composable
fun Inicio(apps: List<AppRow>?, goTab: (Int) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shiz = LocalShiz.current
    var s by remember { mutableStateOf(snap(ctx)) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            s = snap(ctx)
            delay(2000)
        }
    }
    val (score, tips) = advise(ctx, s, apps, shiz)
    val anim by animateFloatAsState(score / 100f, tween(1200), label = "score")
    val col = when {
        score >= 80 -> Color(0xFF66BB6A)
        score >= 55 -> Color(0xFFFFCA28)
        else -> Color(0xFFEF5350)
    }
    val verdict = when {
        score >= 80 -> "Tu teléfono está en buen estado"
        score >= 55 -> "Hay cosas por mejorar"
        else -> "Necesita mantenimiento"
    }
    val screenMin = (apps ?: emptyList()).sumOf { it.fgMin }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("KilTeef oneplus v2.0", style = MaterialTheme.typography.headlineSmall)
        Appear(0) {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(120.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val w = 14.dp.toPx()
                            val tl = Offset(w / 2, w / 2)
                            val sz = Size(size.width - w, size.height - w)
                            drawArc(Color(0x33FFFFFF), -90f, 360f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                            drawArc(col, -90f, 360f * anim, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                        }
                        Text("${(anim * 100).toInt()}", fontSize = 34.sp, color = col)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Salud del teléfono", style = MaterialTheme.typography.labelLarge)
                        Text(verdict, style = MaterialTheme.typography.titleMedium)
                        Text("${tips.count { it.level > 0 }} sugerencias", fontSize = 12.sp)
                    }
                }
            }
        }
        Button({
            if (!busy) {
                busy = true
                scope.launch {
                    val before = snap(ctx)
                    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    (apps ?: emptyList()).filter { !it.system && it.pkg != ctx.packageName }
                        .forEach { am.killBackgroundProcesses(it.pkg) }
                    if (shiz) Sh.runIO("pm trim-caches 999G")
                    delay(1500)
                    val after = snap(ctx)
                    toast(ctx, "RAM: ${before.ramUsedMb} → ${after.ramUsedMb} MB" + (if (shiz) " · caché limpiada" else ""))
                    busy = false
                }
            }
        }, Modifier.fillMaxWidth()) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("⚡ Optimizar ahora")
        }

        Appear(1) {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Pulse(tempColor(s.temp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Temperatura de batería", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "%.1f °C · %s".format(s.temp, tempLabel(s.temp)),
                            style = MaterialTheme.typography.titleMedium, color = tempColor(s.temp)
                        )
                    }
                }
            }
        }
        Appear(2) {
            Info(
                "Batería",
                "${s.pct}%" + (if (s.charging) " ⚡ cargando" else "") +
                    "\nSalud: ${healthText(s.health)}" + (if (s.cycles > 0) " · ${s.cycles} ciclos" else "")
            )
        }
        Appear(3) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Info("RAM", "${s.ramUsedMb} / ${s.ramTotalMb} MB en uso")
                AnimBar(s.ramUsedMb / s.ramTotalMb.coerceAtLeast(1).toFloat())
            }
        }
        Appear(4) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Info("Almacenamiento", "%.0f / %.0f GB usados".format(s.stoUsedGb, s.stoTotalGb))
                AnimBar(s.stoUsedGb / s.stoTotalGb.coerceAtLeast(1f))
            }
        }
        Appear(5) {
            Info(
                "Uso del teléfono (24 h)",
                "${screenMin / 60} h ${screenMin % 60} min en apps · encendido hace %.1f h".format(s.uptimeH)
            )
        }
        Appear(6) {
            Info("Software", "${Build.MODEL} · Android ${Build.VERSION.RELEASE}\n${Build.DISPLAY}\nParche: ${Build.VERSION.SECURITY_PATCH}")
        }

        Text("Sugerencias (toca una para ir)", style = MaterialTheme.typography.titleMedium)
        tips.forEachIndexed { i, t ->
            Appear(i + 2) {
                Card(
                    Modifier.fillMaxWidth().clickable { goTab(t.tab) },
                    colors = CardDefaults.cardColors(
                        containerColor = when (t.level) {
                            2 -> Color(0x33EF5350)
                            1 -> Color(0x33FFCA28)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                    )
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.icon, fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(t.title, style = MaterialTheme.typography.titleSmall)
                            Text(t.text, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
