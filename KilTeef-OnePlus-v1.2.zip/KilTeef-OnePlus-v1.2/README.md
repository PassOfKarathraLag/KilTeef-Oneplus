# KilTeef oneplus v1.2
Monitor de CPU/calor, procesos, limpieza, vigilante de cámara/micrófono y auditoría de permisos
para OnePlus 11 (OxygenOS) sin root.

Al subir el proyecto a GitHub, la pestaña **Actions** compila el APK y lo publica en **Releases**.
