package com.kilteef.oneplus

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Info(title: String, body: String, color: Color = Color.Unspecified) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(body, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }
}

@Composable
fun Btn(text: String, onClick: () -> Unit) =
    OutlinedButton(onClick, Modifier.fillMaxWidth()) { Text(text) }

@Composable
fun Title(text: String) =
    Text(text, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp))

fun tempLabel(t: Float) = when {
    t < 35 -> "Normal"
    t < 40 -> "Tibia"
    t < 43 -> "Caliente"
    else -> "Muy caliente"
}

fun tempColor(t: Float) = when {
    t < 40 -> Color(0xFF66BB6A)
    t < 43 -> Color(0xFFFFCA28)
    else -> Color(0xFFEF5350)
}

fun push(l: MutableList<Float>, v: Float) {
    l.add(v)
    if (l.size > 90) l.removeAt(0)
}

@Composable
fun Chart(h: List<Float>, color: Color) {
    Card(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(100.dp).padding(12.dp)) {
            if (h.size < 2) return@Canvas
            val lo = h.min() - 1f
            val hi = h.max() + 1f
            val path = Path()
            h.forEachIndexed { i, v ->
                val x = size.width * i / (h.size - 1)
                val y = size.height * (1f - (v - lo) / (hi - lo))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(width = 4f))
        }
    }
}

@Composable
fun AppCard(a: AppRow) {
    val ctx = LocalContext.current
    val pad = PaddingValues(horizontal = 6.dp)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(a.name, style = MaterialTheme.typography.titleSmall)
            Text(a.pkg, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Uso 24 h: ${a.fgMin} min · último uso: ${ago(maxOf(a.last, a.lastAny))}" +
                    (if (a.fgs > 0) " · servicios 1er plano: ${a.fgs}" else "") +
                    " · ${a.totalMb} MB (caché ${a.cacheMb} MB)",
                fontSize = 12.sp
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton({
                    (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(a.pkg)
                    toast(ctx, "Orden enviada a ${a.name}")
                }, contentPadding = pad) { Text("Detener", fontSize = 13.sp) }
                TextButton({ go(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, a.pkg) }, contentPadding = pad) { Text("Info", fontSize = 13.sp) }
                TextButton({ openPerms(ctx, a.pkg) }, contentPadding = pad) { Text("Permisos", fontSize = 13.sp) }
                if (!a.system) TextButton({ go(ctx, Intent.ACTION_DELETE, a.pkg) }, contentPadding = pad) { Text("Desinstalar", fontSize = 13.sp) }
            }
        }
    }
}
