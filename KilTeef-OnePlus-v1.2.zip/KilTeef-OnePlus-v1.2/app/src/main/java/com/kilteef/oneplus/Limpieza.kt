package com.kilteef.oneplus

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.io.File

@Composable
fun Limpieza(apps: List<AppRow>?, reload: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<FileRow>?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val sel = remember { mutableStateListOf<String>() }
    val allFiles = Environment.isExternalStorageManager()
    val selBytes = (files ?: emptyList()).filter { it.path in sel }.sumOf { it.bytes }
    val old = (apps ?: emptyList()).filter { a ->
        val t = maxOf(a.last, a.lastAny)
        !a.system && (t == 0L || System.currentTimeMillis() - t > 30L * 86400_000)
    }.sortedByDescending { it.totalMb }.take(20)

    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Title("Limpieza") }
        item {
            Info(
                "Sobre las 'versiones anteriores'",
                "Los restos de actualizaciones del sistema viven en zonas protegidas que una app sin root no ve. Aquí busco lo que SÍ está en tu almacenamiento: APK viejos, paquetes de actualización, temporales, descargas de más de 60 días, archivos de más de 200 MB y posibles duplicados."
            )
        }
        item {
            Btn("⚡ Liberar RAM (detener apps en segundo plano)") {
                val before = snap(ctx).ramUsedMb
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                (apps ?: emptyList()).filter { !it.system && it.pkg != ctx.packageName }
                    .forEach { am.killBackgroundProcesses(it.pkg) }
                scope.launch {
                    delay(1500)
                    toast(ctx, "RAM en uso: $before → ${snap(ctx).ramUsedMb} MB")
                }
            }
        }
        if (!allFiles) {
            item { Btn("Dar 'Acceso a todos los archivos' para escanear") { go(ctx, Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, ctx.packageName) } }
        } else {
            item {
                Btn(if (scanning) "Escaneando… (puede tardar)" else "🔍 Escanear almacenamiento") {
                    if (!scanning) {
                        scanning = true
                        sel.clear()
                        scope.launch {
                            files = withContext(Dispatchers.IO) { scan() }
                            scanning = false
                        }
                    }
                }
            }
        }
        files?.let { fl ->
            if (fl.isEmpty()) {
                item { Text("No encontré archivos sobrantes. 👍") }
            } else {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button({ sel.clear(); sel.addAll(fl.filter { it.suggest }.map { it.path }) }) { Text("Seleccionar sugeridos") }
                        Spacer(Modifier.width(8.dp))
                        TextButton({ sel.clear() }) { Text("Ninguno") }
                    }
                }
                item { Text("Sugeridos = APK, actualizaciones y temporales. Los duplicados, descargas viejas y archivos grandes los eliges tú.", fontSize = 11.sp) }
                items(fl, key = { it.path }) { f ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(f.path in sel, { c -> if (c) sel.add(f.path) else sel.remove(f.path) })
                        Column(Modifier.weight(1f)) {
                            Text(File(f.path).name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text("${f.kind} · ${fmt(f.bytes)} · ${File(f.path).parent}", fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                item {
                    Button({ confirm = true }, Modifier.fillMaxWidth(), enabled = sel.isNotEmpty()) {
                        Text("Borrar ${sel.size} seleccionados (${fmt(selBytes)})")
                    }
                }
            }
        }

        item { Title("Apps sin usar (30+ días)") }
        item { Text("Según el registro de Android. Si no las necesitas, desinstalarlas libera espacio y quita procesos.", fontSize = 12.sp) }
        if (apps == null) item { Text("Analizando…") } else items(old, key = { "u" + it.pkg }) { AppCard(it) }

        item { Title("Apps que más ocupan") }
        item { Text("Android no deja que una app borre la caché de otras sin root: abre 'Info' → Almacenamiento → Borrar caché.", fontSize = 12.sp) }
        if (apps == null) {
            item { Text("Analizando…") }
        } else {
            items(apps.sortedByDescending { it.totalMb }.take(25), key = { "s" + it.pkg }) { AppCard(it) }
            item { Title("Apps con más caché") }
            items(apps.sortedByDescending { it.cacheMb }.take(15), key = { "c" + it.pkg }) { AppCard(it) }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("¿Borrar ${sel.size} archivos?") },
        text = { Text("Se eliminan de forma permanente (${fmt(selBytes)}). Revisa la lista: en los duplicados se conserva el más antiguo, pero comprueba antes de borrar.") },
        confirmButton = {
            TextButton({
                var n = 0
                sel.forEach { if (File(it).delete()) n++ }
                files = files?.filter { File(it.path).exists() }
                sel.clear()
                confirm = false
                toast(ctx, "$n archivos borrados")
            }) { Text("Borrar") }
        },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancelar") } }
    )
}
