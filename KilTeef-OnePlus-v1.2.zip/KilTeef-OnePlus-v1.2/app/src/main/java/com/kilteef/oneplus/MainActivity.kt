package com.kilteef.oneplus

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

val TABS = listOf(
    "🏠" to "Inicio", "⚙️" to "CPU", "📋" to "Apps",
    "🧹" to "Limpieza", "🔒" to "Privacidad", "📱" to "Pantalla"
)

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var testing by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<AppRow>?>(null) }
    val reload: () -> Unit = {
        scope.launch {
            apps = null
            apps = withContext(Dispatchers.IO) { loadApps(ctx) }
        }
    }
    LaunchedEffect(Unit) { reload() }

    if (testing) {
        ScreenTest { testing = false }
    } else {
        Scaffold(bottomBar = {
            NavigationBar {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(t.first) },
                        label = { Text(t.second, fontSize = 10.sp, maxLines = 1) }
                    )
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> Resumen()
                    1 -> Cpu()
                    2 -> Procesos(apps, reload)
                    3 -> Limpieza(apps, reload)
                    4 -> Privacidad()
                    else -> Pantalla { testing = true }
                }
            }
        }
    }
}

// ---------- 1. Resumen ----------

@Composable
fun Resumen() {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(snap(ctx)) }
    LaunchedEffect(Unit) { while (true) { s = snap(ctx); delay(2000) } }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("KilTeef oneplus v1", style = MaterialTheme.typography.headlineSmall)
        Info("Batería", "${s.pct}%" + if (s.charging) " ⚡ cargando" else "")
        Info("Temperatura de batería", "%.1f °C · %s".format(s.temp, tempLabel(s.temp)), tempColor(s.temp))
        Info("Estado térmico del sistema", thermalName(s.thermal))
        Info("RAM", "${s.ramUsedMb} / ${s.ramTotalMb} MB en uso")
        LinearProgressIndicator(progress = { s.ramUsedMb / s.ramTotalMb.toFloat() }, modifier = Modifier.fillMaxWidth())
        Info("Almacenamiento", "%.0f / %.0f GB usados".format(s.stoUsedGb, s.stoTotalGb))
        Info("Encendido desde hace", "%.1f horas".format(s.uptimeH))
        if (s.uptimeH > 72) Text("Llevas más de 3 días sin reiniciar: reiniciar libera RAM y procesos pegados.", fontSize = 12.sp)
        Info("Software", "${Build.MODEL} · Android ${Build.VERSION.RELEASE}\n${Build.DISPLAY}\nParche de seguridad: ${Build.VERSION.SECURITY_PATCH}")
        Text("Atajos del sistema", style = MaterialTheme.typography.titleMedium)
        Btn("Optimización de batería por app") { go(ctx, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
        Btn("Ahorro de batería") { go(ctx, Settings.ACTION_BATTERY_SAVER_SETTINGS) }
        Btn("Servicios en ejecución (opciones de desarrollador)") { go(ctx, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) }
    }
}

// ---------- 2. Procesos ----------

@Composable
fun Procesos(apps: List<AppRow>?, reload: () -> Unit) {
    val ctx = LocalContext.current
    var sys by remember { mutableStateOf(false) }
    val granted = hasUsage(ctx)
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Title("Procesos y segundo plano") }
        if (!granted) item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Info("Falta un permiso", "Activa 'Acceso de uso' para KilTeef. Sin él Android no me deja ver qué apps están activas.")
                Btn("Dar acceso de uso") { go(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS, ctx.packageName) }
                Btn("Ya lo activé · actualizar") { reload() }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(sys, { sys = it })
                Spacer(Modifier.width(8.dp))
                Text("Mostrar apps del sistema", fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                TextButton({ reload() }) { Text("Actualizar") }
            }
        }
        if (apps == null) {
            item { Text("Analizando…") }
        } else {
            val list = apps.filter { sys || !it.system }
            val active = list.filter { it.fgsOn }
            item { Text("🔴 Servicios en primer plano activos (${active.size})", style = MaterialTheme.typography.titleMedium) }
            item { Text("Son las apps que mantienen un servicio corriendo (suelen mostrar notificación). Cálculo aproximado de las últimas 24 h.", fontSize = 11.sp) }
            items(active, key = { "a" + it.pkg }) { AppCard(it) }
            item { Text("⏱ Más usadas en 24 h", style = MaterialTheme.typography.titleMedium) }
            items(
                list.filter { it.fgMin > 0 || it.fgs > 0 }.sortedByDescending { it.fgMin }.take(40),
                key = { "b" + it.pkg }
            ) { AppCard(it) }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

// ---------- 5. Pantalla / línea verde ----------

@Composable
fun Pantalla(onTest: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Línea verde en la pantalla", style = MaterialTheme.typography.headlineSmall)
        Info(
            "Lo que sí y lo que no",
            "Una app no puede reparar una línea verde: casi siempre es el panel AMOLED o su conexión (hardware). Sí puedo ayudarte a comprobarlo y a documentarlo."
        )
        Btn("▶ Iniciar prueba de colores a pantalla completa") { onTest() }
        Info(
            "Cómo interpretar el resultado",
            "1) Con la línea visible, toma una captura de pantalla.\n" +
                "2) Si la línea NO sale en la captura → es hardware (panel).\n" +
                "3) Si SÍ sale en la captura → puede ser software: actualiza OxygenOS, haz copia de seguridad y prueba un restablecimiento.\n" +
                "4) Anota si aparece con calor, brillo bajo/alto o 60/120 Hz: sirve para soporte."
        )
        Info(
            "Garantía",
            "OnePlus anunció garantía de por vida de pantalla para la línea verde (diciembre 2024). La cobertura depende del país de compra: confirma en un centro de servicio OnePlus en México."
        )
        Btn("Ajustes de pantalla (60/120 Hz)") { go(ctx, Settings.ACTION_DISPLAY_SETTINGS) }
    }
}

@Composable
fun ScreenTest(onExit: () -> Unit) {
    val colors = listOf(Color.Black, Color.White, Color.Red, Color.Green, Color.Blue, Color.Gray)
    var i by remember { mutableIntStateOf(0) }
    val view = LocalView.current
    DisposableEffect(Unit) {
        val c = WindowCompat.getInsetsController((view.context as Activity).window, view)
        c.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { c.show(WindowInsetsCompat.Type.systemBars()) }
    }
    val bg = colors[i]
    Box(
        Modifier.fillMaxSize().background(bg).pointerInput(Unit) {
            detectTapGestures { if (i < colors.lastIndex) i++ else onExit() }
        },
        contentAlignment = Alignment.BottomCenter
    ) {
        Text(
            "Toca para cambiar de color (${i + 1}/${colors.size}) · al final sales",
            color = if (bg == Color.White) Color.Black else Color.White,
            fontSize = 12.sp, modifier = Modifier.padding(24.dp)
        )
    }
}
