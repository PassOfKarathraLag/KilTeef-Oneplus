package com.kilteef.oneplus

import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

@Composable
fun Cpu() {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(snap(ctx)) }
    var cores by remember { mutableStateOf(emptyList<Core>()) }
    var gpu by remember { mutableLongStateOf(-1L) }
    var zones by remember { mutableStateOf(emptyList<Pair<String, Float>>()) }
    var load by remember { mutableFloatStateOf(0f) }
    var maxT by remember { mutableFloatStateOf(0f) }
    val loadH = remember { mutableStateListOf<Float>() }
    val wattH = remember { mutableStateListOf<Float>() }
    val tempH = remember { mutableStateListOf<Float>() }

    LaunchedEffect(Unit) {
        while (true) {
            s = snap(ctx)
            val r = withContext(Dispatchers.IO) { Triple(readCores(), readGpuMhz(), readZones()) }
            cores = r.first
            gpu = r.second
            zones = r.third
            val ok = cores.filter { it.cur > 0 && it.max > 0 }
            load = if (ok.isEmpty()) 0f else ok.map { it.cur * 100f / it.max }.average().toFloat()
            push(loadH, load)
            push(tempH, s.temp)
            push(wattH, s.ma / 1000f * s.volt)
            maxT = maxOf(maxT, s.temp)
            delay(1500)
        }
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("CPU, consumo y calor", style = MaterialTheme.typography.headlineSmall)
        Info("Carga estimada de CPU", "%.0f %%".format(load))
        Chart(loadH, Color(0xFF42A5F5))
        Text("Se estima con la frecuencia de cada núcleo: Android bloquea el % real (/proc/stat) sin root. Si la frecuencia sube, hay carga.", fontSize = 11.sp)

        Text("Núcleos", style = MaterialTheme.typography.titleMedium)
        if (cores.isEmpty() || cores.all { it.cur <= 0 }) Text("No pude leer las frecuencias en este equipo.", fontSize = 12.sp)
        cores.forEach { c ->
            val on = c.cur > 0 && c.max > 0
            Column {
                Text(
                    if (on) "CPU${c.id}: ${c.cur / 1000} / ${c.max / 1000} MHz · ${c.gov}" else "CPU${c.id}: en reposo o no legible",
                    fontSize = 12.sp
                )
                LinearProgressIndicator(
                    progress = { if (on) (c.cur.toFloat() / c.max).coerceIn(0f, 1f) else 0f },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Info("GPU", if (gpu > 0) "$gpu MHz" else "No legible sin root")

        Info(
            "Consumo del teléfono ahora",
            "%d mA · %.1f W%s".format(s.ma, s.ma / 1000f * s.volt, if (s.charging) " (cargando)" else "")
        )
        Chart(wattH, Color(0xFFFFCA28))

        Info("Temperatura de batería", "%.1f °C · %s".format(s.temp, tempLabel(s.temp)), tempColor(s.temp))
        Chart(tempH, Color(0xFFFF7043))
        Info("Máxima de esta sesión", "%.1f °C".format(maxT))
        Info(
            "Estado térmico del sistema",
            thermalName(s.thermal) + "\nMargen: " +
                (if (s.headroom.isNaN()) "no disponible" else "%.2f (1.0 = el sistema empieza a limitar rendimiento)".format(s.headroom))
        )
        if (zones.isEmpty()) {
            Text("Sensores internos de CPU/GPU: Android los bloquea sin root o ADB. Es normal.", fontSize = 12.sp)
        } else {
            Info("Sensores internos", zones.take(12).joinToString("\n") { "%s: %.1f °C".format(it.first, it.second) })
        }

        Text("Plan de enfriamiento", style = MaterialTheme.typography.titleMedium)
        Text(
            "• Quita la funda y no uses el teléfono mientras carga.\n" +
                "• Pantalla en 60 Hz y brillo moderado.\n" +
                "• Si calienta con datos móviles, prueba 4G/LTE en vez de 5G.\n" +
                "• Mira la pestaña Apps: servicios activos que no uses.\n" +
                "• Si pasa de ~45 °C en reposo y sin cargar, llévalo a servicio técnico.",
            fontSize = 13.sp
        )
        Btn("Pantalla: frecuencia de actualización y brillo") { go(ctx, Settings.ACTION_DISPLAY_SETTINGS) }
        Btn("Red móvil: elegir 4G/LTE o 5G") { go(ctx, Settings.ACTION_NETWORK_OPERATOR_SETTINGS) }
        Btn("Ahorro de batería") { go(ctx, Settings.ACTION_BATTERY_SAVER_SETTINGS) }
    }
}
