package com.kilteef.oneplus

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

val MODES = listOf("📷" to "Cámara", "🎤" to "Micrófono", "📍" to "Ubicación en segundo plano", "⏰" to "Alarmas exactas")
val MODE_TIPS = listOf(
    "Apps con permiso de CÁMARA concedido. Las marcadas con 🔴 tienen además un servicio activo: desde Android 11 son las únicas que pueden usarla en segundo plano.",
    "Apps con permiso de MICRÓFONO concedido. Las marcadas con 🔴 tienen además un servicio activo: son las únicas que pueden grabar en segundo plano.",
    "Apps con ubicación en segundo plano permitida: pueden seguirte aunque no las abras.",
    "Apps que piden alarmas exactas (despiertan el teléfono a horas fijas y gastan batería). Pulsa 'Alarmas' para permitir o denegar. Las de reloj/calendario usan un permiso que no se puede quitar."
)
val MODE_PERMS = listOf(
    "android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.ACCESS_BACKGROUND_LOCATION"
)

@Composable
fun Privacidad() {
    val ctx = LocalContext.current
    val on = GuardService.running.value
    val ev = Events.items.toList()
    var perms by remember { mutableStateOf<List<PermRow>?>(null) }
    var mode by remember { mutableIntStateOf(0) }
    var sys by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        Events.init(ctx)
        perms = withContext(Dispatchers.IO) { loadPerms(ctx) }
    }

    val list = (perms ?: emptyList())
        .filter { p ->
            (sys || !p.system) && when (mode) {
                0 -> p.cam
                1 -> p.mic
                2 -> p.bgLoc
                else -> p.alarm
            }
        }
        .sortedWith(compareByDescending<PermRow> { it.fgsOn }.thenBy { it.name.lowercase() })

    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Title("Privacidad") }
        item { Info("Vigilante de cámara y micrófono", if (on) "🟢 ACTIVO" else "⚪ Apagado") }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(on, { want ->
                    if (want) {
                        if (ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        ctx.startForegroundService(Intent(ctx, GuardService::class.java))
                    } else {
                        ctx.stopService(Intent(ctx, GuardService::class.java))
                    }
                })
                Spacer(Modifier.width(8.dp))
                Text("Avisarme cuando alguna app abra la cámara o el micrófono", fontSize = 13.sp)
            }
        }
        item {
            Text(
                "Android no dice QUÉ app los usa, así que te doy pistas: la app que estaba al frente, si la pantalla estaba apagada y qué apps con permiso tienen un servicio activo. Solo vigila mientras el vigilante esté encendido (deja una notificación fija). Puede saltar por asistentes de voz o desbloqueo facial.",
                fontSize = 11.sp
            )
        }
        item { Btn("🔋 Quitar restricción de batería a KilTeef") { go(ctx, Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, ctx.packageName) } }
        item { Btn("🛡 Panel de privacidad del sistema (quién usó cámara/micro)") { openPrivacyDashboard(ctx) } }

        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Historial de avisos", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton({ Events.clear(ctx) }) { Text("Borrar") }
            }
        }
        if (ev.isEmpty()) item { Text("Sin avisos todavía.", fontSize = 12.sp) } else items(ev.take(20)) { Text(it, fontSize = 11.sp) }

        item { Title("Auditoría de permisos") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MODES.forEachIndexed { i, m ->
                    val mod = Modifier.weight(1f)
                    if (mode == i) Button({ mode = i }, mod, contentPadding = PaddingValues(0.dp)) { Text(m.first) }
                    else OutlinedButton({ mode = i }, mod, contentPadding = PaddingValues(0.dp)) { Text(m.first) }
                }
            }
        }
        item { Text(MODES[mode].second, style = MaterialTheme.typography.titleMedium) }
        item { Text(MODE_TIPS[mode], fontSize = 12.sp) }
        item {
            Text(
                "Android no permite que una app quite permisos a otras. El botón 'Quitar permisos' abre la pantalla exacta del sistema para esa app y allí lo haces con un toque.",
                fontSize = 11.sp
            )
        }
        if (mode < 3) item { Btn("Ver en el sistema: todas las apps con este permiso") { openPermApps(ctx, MODE_PERMS[mode]) } }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(sys, { sys = it })
                Spacer(Modifier.width(8.dp))
                Text("Incluir apps del sistema", fontSize = 13.sp)
            }
        }
        if (perms == null) item { Text("Analizando permisos…") } else items(list, key = { it.pkg }) { PermCard(it) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun PermCard(p: PermRow) {
    val ctx = LocalContext.current
    val pad = PaddingValues(horizontal = 6.dp)
    val tags = listOfNotNull(
        if (p.cam) "📷 cámara" else null,
        if (p.mic) "🎤 micro" else null,
        if (p.bgLoc) "📍 ubic. 2º plano" else null,
        if (p.alarm) "⏰ alarmas exactas" else null
    ).joinToString(" · ")
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(p.name, style = MaterialTheme.typography.titleSmall)
            Text(p.pkg, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(tags + if (p.fgsOn) "\n🔴 tiene un servicio activo ahora" else "", fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton({ openPerms(ctx, p.pkg) }, contentPadding = pad) { Text("Quitar permisos", fontSize = 13.sp) }
                if (p.alarm) TextButton({ openAlarm(ctx, p.pkg) }, contentPadding = pad) { Text("Alarmas", fontSize = 13.sp) }
                TextButton({ go(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, p.pkg) }, contentPadding = pad) { Text("Info", fontSize = 13.sp) }
            }
        }
    }
}
