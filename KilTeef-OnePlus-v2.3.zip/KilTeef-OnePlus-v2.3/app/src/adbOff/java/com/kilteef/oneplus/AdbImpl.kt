package com.kilteef.oneplus

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Adb {
    val supported = false
    var status by mutableStateOf("Esta compilación no incluye ADB integrado")
    fun connected(): Boolean = false
    fun run(cmd: String): String = "ADB integrado no disponible"
    fun begin(ctx: Context) {}
    fun reconnect(ctx: Context): Boolean = false
}

class AdbService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
}
