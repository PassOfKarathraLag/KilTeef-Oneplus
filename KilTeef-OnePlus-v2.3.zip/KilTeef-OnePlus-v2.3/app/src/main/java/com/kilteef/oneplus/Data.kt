package com.kilteef.oneplus

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.os.storage.StorageManager
import android.provider.Settings
import android.widget.Toast
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import kotlin.math.abs

// ================= Estado general =================

data class Snap(
    val pct: Int, val temp: Float, val charging: Boolean,
    val thermal: Int, val headroom: Float,
    val ramUsedMb: Long, val ramTotalMb: Long,
    val stoUsedGb: Float, val stoTotalGb: Float, val uptimeH: Float,
    val ma: Long, val volt: Float,
    val health: Int, val cycles: Int
)

fun snap(ctx: Context): Snap {
    val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val scl = (b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
    val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val ua = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
    val ma = if (ua == Long.MIN_VALUE || ua == 0L) 0L else if (abs(ua) > 20000) abs(ua) / 1000 else abs(ua)
    val mi = ActivityManager.MemoryInfo()
    (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
    val sf = StatFs(Environment.getDataDirectory().path)
    return Snap(
        pct = lvl * 100 / scl,
        temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f,
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL,
        thermal = pm.currentThermalStatus,
        headroom = try { pm.getThermalHeadroom(10) } catch (e: Exception) { Float.NaN },
        ramUsedMb = (mi.totalMem - mi.availMem) / 1048576,
        ramTotalMb = mi.totalMem / 1048576,
        stoUsedGb = (sf.totalBytes - sf.availableBytes) / 1e9f,
        stoTotalGb = sf.totalBytes / 1e9f,
        uptimeH = SystemClock.elapsedRealtime() / 3.6e6f,
        ma = ma,
        volt = (b?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0) / 1000f,
        health = b?.getIntExtra(BatteryManager.EXTRA_HEALTH, 1) ?: 1,
        cycles = b?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) ?: -1
    )
}

fun thermalName(t: Int) =
    listOf("Normal", "Ligero", "Moderado", "Severo", "Crítico", "Emergencia", "Apagado")[t.coerceIn(0, 6)]

fun hasUsage(ctx: Context): Boolean {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    return ops.unsafeCheckOpNoThrow(
        AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
    ) == AppOpsManager.MODE_ALLOWED
}

// ================= CPU / GPU =================

data class Core(val id: Int, val cur: Long, val max: Long, val gov: String)

/** Frecuencias por núcleo (kHz). scaling_cur_freq suele ser legible sin root. */
fun readCores(): List<Core> {
    val dirs = File("/sys/devices/system/cpu").listFiles { f -> f.name.matches(Regex("cpu[0-9]+")) }
        ?.sortedBy { it.name.substring(3).toInt() } ?: return emptyList()
    return dirs.map { d ->
        fun rd(n: String): String = try { File(d, "cpufreq/$n").readText().trim() } catch (e: Exception) { "" }
        Core(
            d.name.substring(3).toInt(),
            rd("scaling_cur_freq").toLongOrNull() ?: -1L,
            (rd("cpuinfo_max_freq").ifEmpty { rd("scaling_max_freq") }).toLongOrNull() ?: -1L,
            rd("scaling_governor")
        )
    }
}

fun readGpuMhz(): Long {
    for (p in listOf("/sys/class/kgsl/kgsl-3d0/gpuclk", "/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq")) {
        try {
            val v = File(p).readText().trim().toLong()
            if (v > 0) return v / 1_000_000
        } catch (e: Exception) { }
    }
    return -1L
}

/** Sensores térmicos internos: Android suele bloquearlos sin root/ADB. */
fun readZones(): List<Pair<String, Float>> =
    File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
        ?.sortedBy { it.name }
        ?.mapNotNull { z ->
            try {
                val t = File(z, "temp").readText().trim().toFloat()
                File(z, "type").readText().trim() to (if (t > 1000f) t / 1000f else t)
            } catch (e: Exception) { null }
        } ?: emptyList()

// ================= Apps =================

data class AppRow(
    val pkg: String, val name: String, val system: Boolean,
    val fgMin: Long, val last: Long, val lastAny: Long,
    val fgs: Int, val fgsOn: Boolean, val cacheMb: Long, val totalMb: Long
)

fun labelOf(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))).toString()
} catch (e: Exception) { pkg }

fun loadApps(ctx: Context): List<AppRow> {
    val pm = ctx.packageManager
    val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
    val now = System.currentTimeMillis()
    val from = now - 24L * 3600_000
    val use = HashMap<String, Pair<Long, Long>>()
    try {
        for (u in usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, from, now)) {
            val o = use[u.packageName]
            use[u.packageName] = Pair(
                (o?.first ?: 0L) + u.totalTimeInForeground,
                maxOf(o?.second ?: 0L, u.lastTimeUsed)
            )
        }
    } catch (x: Exception) { }
    val any = HashMap<String, Long>()
    try {
        for (u in usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, now - 90L * 86400_000, now)) {
            any[u.packageName] = maxOf(any[u.packageName] ?: 0L, u.lastTimeUsed)
        }
    } catch (x: Exception) { }
    val fgs = HashMap<String, Int>()
    val on = HashSet<String>()
    try {
        val ev = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == 19) {          // servicio en primer plano iniciado
                fgs[e.packageName] = (fgs[e.packageName] ?: 0) + 1
                on.add(e.packageName)
            } else if (e.eventType == 20) {   // servicio en primer plano detenido
                on.remove(e.packageName)
            }
        }
    } catch (x: Exception) { }
    val me = Process.myUserHandle()
    return pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0)).map { a ->
        var cache = 0L
        var total = 0L
        try {
            val s = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, a.packageName, me)
            cache = s.cacheBytes / 1048576
            total = (s.appBytes + s.dataBytes) / 1048576
        } catch (x: Exception) { }
        AppRow(
            pkg = a.packageName, name = a.loadLabel(pm).toString(),
            system = (a.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
            fgMin = (use[a.packageName]?.first ?: 0L) / 60000,
            last = use[a.packageName]?.second ?: 0L,
            lastAny = any[a.packageName] ?: 0L,
            fgs = fgs[a.packageName] ?: 0, fgsOn = a.packageName in on,
            cacheMb = cache, totalMb = total
        )
    }
}

/** Paquetes con un servicio en primer plano posiblemente activo (últimas 24 h). */
fun fgsActive(ctx: Context): Set<String> {
    val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val on = HashSet<String>()
    try {
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 24L * 3600_000, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == 19) on.add(e.packageName) else if (e.eventType == 20) on.remove(e.packageName)
        }
    } catch (x: Exception) { }
    return on
}

/** App que probablemente está al frente (según eventos de uso de la última hora). */
fun foregroundPkg(ctx: Context): String? {
    val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    var cur: String? = null
    try {
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 3600_000, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == 1) cur = e.packageName
            else if ((e.eventType == 2 || e.eventType == 23) && e.packageName == cur) cur = null
        }
    } catch (x: Exception) { }
    return cur
}

// ================= Permisos =================

data class PermRow(
    val pkg: String, val name: String, val system: Boolean,
    val cam: Boolean, val mic: Boolean, val bgLoc: Boolean, val alarm: Boolean, val fgsOn: Boolean
)

fun loadPerms(ctx: Context): List<PermRow> {
    val pm = ctx.packageManager
    val on = fgsActive(ctx)
    val flags = PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
    return pm.getInstalledPackages(flags).mapNotNull { p ->
        val req = p.requestedPermissions?.toSet() ?: return@mapNotNull null
        val ai = p.applicationInfo ?: return@mapNotNull null
        fun ok(perm: String): Boolean =
            perm in req && pm.checkPermission(perm, p.packageName) == PackageManager.PERMISSION_GRANTED
        val cam = ok("android.permission.CAMERA")
        val mic = ok("android.permission.RECORD_AUDIO")
        val bg = ok("android.permission.ACCESS_BACKGROUND_LOCATION")
        val alarm = "android.permission.SCHEDULE_EXACT_ALARM" in req || "android.permission.USE_EXACT_ALARM" in req
        if (cam || mic || bg || alarm) {
            PermRow(p.packageName, ai.loadLabel(pm).toString(), (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                cam, mic, bg, alarm, p.packageName in on)
        } else null
    }
}

// ================= Archivos =================

data class FileRow(val path: String, val bytes: Long, val kind: String, val suggest: Boolean)
data class ScanResult(val rows: List<FileRow>, val byCat: List<Pair<String, Long>>, val count: Int)

private val EXT_VIDEO = setOf("mp4", "mkv", "avi", "mov", "3gp", "webm", "m4v")
private val EXT_IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "bmp", "dng")
private val EXT_AUD = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr")
private val EXT_DOC = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "epub")
private val EXT_ARC = setOf("zip", "rar", "7z", "tar", "gz", "ozip")

fun catOf(name: String): String {
    val e = name.substringAfterLast('.', "").lowercase()
    return when {
        e in EXT_VIDEO -> "Videos"
        e in EXT_IMG -> "Imágenes"
        e == "apk" -> "APK"
        e in EXT_AUD -> "Audio"
        e in EXT_DOC -> "Documentos"
        e in EXT_ARC -> "Comprimidos"
        else -> "Otros"
    }
}

fun iconOf(cat: String): String = when (cat) {
    "Videos" -> "🎬"
    "Imágenes" -> "🖼"
    "Audio" -> "🎵"
    "APK" -> "📦"
    "Documentos" -> "📄"
    "Comprimidos" -> "🗜"
    else -> "📁"
}

fun fmt(b: Long): String =
    if (b >= 1_000_000_000) "%.1f GB".format(b / 1e9) else if (b >= 1_000_000) "${b / 1_000_000} MB" else "${b / 1000} KB"

fun quickHash(f: File): String? = try {
    val md = MessageDigest.getInstance("MD5")
    RandomAccessFile(f, "r").use { r ->
        val len = r.length()
        val buf = ByteArray(65536)
        for (pos in listOf(0L, maxOf(0L, len / 2 - 32768), maxOf(0L, len - 65536))) {
            r.seek(pos)
            val n = r.read(buf)
            if (n > 0) md.update(buf, 0, n)
        }
    }
    md.digest().joinToString("") { "%02x".format(it) }
} catch (e: Exception) { null }

/** Recorre el almacenamiento: tamaño por tipo, archivos grandes, APK, actualizaciones, temporales, descargas viejas y duplicados. */
fun scan(): ScanResult {
    val root = Environment.getExternalStorageDirectory()
    val dl = File(root, "Download").path
    val now = System.currentTimeMillis()
    val found = LinkedHashMap<String, FileRow>()
    val bySize = HashMap<Long, MutableList<File>>()
    val big = ArrayList<File>()
    val cats = HashMap<String, Long>()
    var count = 0
    root.walkTopDown()
        .onEnter { !(it.name == "Android" && it.parentFile == root) }
        .forEach { f ->
            if (!f.isFile) return@forEach
            count++
            val len = f.length()
            val n = f.name.lowercase()
            val c = catOf(n)
            cats[c] = (cats[c] ?: 0L) + len
            if (len >= 2_000_000) bySize.getOrPut(len) { mutableListOf() }.add(f)
            if (len >= 20_000_000) big.add(f)
            val k: String? = when {
                n.endsWith(".apk") && len >= 500_000 -> "APK"
                n.endsWith(".ozip") ||
                    (n.endsWith(".zip") && len >= 50_000_000 && listOf("ota", "oxygen", "cph", "update").any { n.contains(it) }) -> "Actualización"
                (n.endsWith(".tmp") || n.endsWith(".log") || n.startsWith(".thumbdata") || f.parentFile?.name == ".thumbnails") && len >= 100_000 -> "Temporal"
                len >= 200_000_000 -> "Grande"
                f.path.startsWith(dl) && len >= 5_000_000 && now - f.lastModified() > 60L * 86400_000 -> "Descarga vieja"
                else -> null
            }
            if (k != null) found[f.path] = FileRow(f.path, len, k, k == "APK" || k == "Actualización" || k == "Temporal")
        }
    for (f in big.sortedByDescending { it.length() }.take(60)) {
        if (f.path !in found) found[f.path] = FileRow(f.path, f.length(), "Grande", false)
    }
    for ((len, group) in bySize) {
        if (group.size < 2) continue
        val hashes = HashMap<String, MutableList<File>>()
        for (g in group) {
            val h = quickHash(g) ?: continue
            hashes.getOrPut(h) { mutableListOf() }.add(g)
        }
        for (same in hashes.values) {
            if (same.size < 2) continue
            same.sortBy { it.lastModified() }
            for (d in same.drop(1)) found[d.path] = FileRow(d.path, len, "Duplicado", false)
        }
    }
    return ScanResult(
        found.values.sortedByDescending { it.bytes }.take(150),
        cats.toList().sortedByDescending { it.second },
        count
    )
}

// ================= Utilidades =================

fun ago(t: Long): String {
    if (t <= 0) return "sin registro"
    val m = (System.currentTimeMillis() - t) / 60000
    return if (m < 60) "hace $m min" else if (m < 1440) "hace ${m / 60} h" else "hace ${m / 1440} d"
}


fun tryStart(ctx: Context, i: Intent): Boolean = try {
    ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
} catch (e: Exception) { false }

/** Abre una pantalla de ajustes del sistema (opcionalmente de un paquete). */
fun go(ctx: Context, action: String, pkg: String? = null): Boolean {
    val i = Intent(action)
    if (pkg != null) i.data = Uri.parse("package:$pkg")
    val ok = tryStart(ctx, i)
    if (!ok) toast(ctx, "Tu sistema no permite abrir esa pantalla")
    return ok
}

/** Pantalla de permisos de una app; si OxygenOS no lo permite, abre Info de la app. */
fun openPerms(ctx: Context, pkg: String) {
    val i = Intent("android.intent.action.MANAGE_APP_PERMISSIONS").putExtra("android.intent.extra.PACKAGE_NAME", pkg)
    if (!tryStart(ctx, i)) go(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
}

/** Lista del sistema: qué apps tienen un permiso concreto (cámara, micrófono...). */
fun openPermApps(ctx: Context, perm: String) {
    val i = Intent("android.intent.action.MANAGE_PERMISSION_APPS").putExtra("android.intent.extra.PERMISSION_NAME", perm)
    if (!tryStart(ctx, i)) go(ctx, Settings.ACTION_PRIVACY_SETTINGS)
}

/** Pantalla "Alarmas y recordatorios" de una app. */
fun openAlarm(ctx: Context, pkg: String) {
    val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$pkg"))
    if (!tryStart(ctx, i)) go(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
}

fun openPrivacyDashboard(ctx: Context) {
    if (!tryStart(ctx, Intent("android.intent.action.REVIEW_PERMISSION_USAGE"))) go(ctx, Settings.ACTION_PRIVACY_SETTINGS)
}

fun agoText(s: Long): String =
    if (s < 60) "$s s" else if (s < 3600) "${s / 60} min" else if (s < 86400) "${s / 3600} h" else "${s / 86400} d"
