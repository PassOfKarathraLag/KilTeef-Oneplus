package com.kilteef.oneplus

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Paleta "KilTeef Night"
val Bg = Color(0xFF0A0E14)
val CardBg = Color(0xFF131A23)
val CardHi = Color(0xFF1A2430)
val Line = Color(0xFF263444)
val Mint = Color(0xFF3DDC97)
val Cyan = Color(0xFF4DD0E1)
val Amber = Color(0xFFFFB74D)
val Coral = Color(0xFFFF6B6B)
val Violet = Color(0xFFB39DDB)
val Dim = Color(0xFF8FA1B3)
val Txt = Color(0xFFE8EEF4)

private val KScheme = darkColorScheme(
    primary = Mint, onPrimary = Color(0xFF00281A),
    secondary = Cyan, onSecondary = Color(0xFF00363D),
    tertiary = Amber,
    background = Bg, onBackground = Txt,
    surface = Bg, onSurface = Txt,
    surfaceVariant = CardHi, onSurfaceVariant = Dim,
    surfaceContainerLowest = Bg, surfaceContainerLow = CardBg, surfaceContainer = CardBg,
    surfaceContainerHigh = CardHi, surfaceContainerHighest = CardBg,
    error = Coral, outline = Line, outlineVariant = Line,
    primaryContainer = Color(0xFF123B2B), onPrimaryContainer = Mint,
    secondaryContainer = Color(0xFF16363B), onSecondaryContainer = Cyan
)

private val KType = Typography().copy(
    headlineSmall = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
    labelLarge = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp)
)

private val KShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun KTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = KScheme, typography = KType, shapes = KShapes, content = content)
}
