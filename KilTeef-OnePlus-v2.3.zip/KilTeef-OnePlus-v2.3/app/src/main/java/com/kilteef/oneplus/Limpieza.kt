package com.kilteef.oneplus

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.io.File

val FILTERS = listOf("Todos", "Grande", "Duplicado", "APK", "Actualización", "Temporal", "Descarga vieja")

@Composable
fun Limpieza(apps: List<AppRow>?, reload: () -> Unit) {
    val ctx = LocalContext.current
    val shiz = LocalShiz.current
    val scope = rememberCoroutineScope()
    val res = Store.scan
    var scanning by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("Todos") }
    var preview by remember { mutableStateOf<FileRow?>(null) }
    val sel = remember { mutableStateListOf<String>() }
    val allFiles = Environment.isExternalStorageManager()
    val rows = (res?.rows ?: emptyList()).filter { filter == "Todos" || it.kind == filter }
    val selBytes = (res?.rows ?: emptyList()).filter { it.path in sel }.sumOf { it.bytes }
    val old = (apps ?: emptyList()).filter { a ->
        val t = maxOf(a.last, a.lastAny)
        !a.system && (t == 0L || System.currentTimeMillis() - t > 30L * 86400_000)
    }.sortedByDescending { it.totalMb }.take(20)

    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Title("Limpieza") }
        item {
            Info(
                "Qué busco",
                "APK viejos, paquetes de actualización, temporales, descargas de más de 60 días, los archivos más grandes y posibles duplicados. Toca un archivo para ver su vista previa. Los restos del sistema (versiones anteriores de OxygenOS) están en zonas protegidas que ninguna app sin root ve."
            )
        }
        item {
            Btn("⚡ Liberar RAM (detener apps en segundo plano)") {
                val before = snap(ctx).ramUsedMb
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                (apps ?: emptyList()).filter { !it.system && it.pkg != ctx.packageName }
                    .forEach { am.killBackgroundProcesses(it.pkg) }
                scope.launch {
                    delay(1500)
                    toast(ctx, "RAM en uso: $before → ${snap(ctx).ramUsedMb} MB")
                }
            }
        }
        if (shiz) {
            item {
                Btn("🧹 Limpiar caché de TODAS las apps (Shizuku)") {
                    val before = snap(ctx).stoUsedGb
                    scope.launch {
                        Sh.runIO("pm trim-caches 999G")
                        delay(800)
                        toast(ctx, "Caché limpiada · liberado ≈ %.2f GB".format(maxOf(0f, before - snap(ctx).stoUsedGb)))
                    }
                }
            }
        }
        if (!allFiles) {
            item { Btn("Dar 'Acceso a todos los archivos' para escanear") { go(ctx, Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, ctx.packageName) } }
        } else {
            item {
                Btn(if (scanning) "Escaneando… (puede tardar)" else "🔍 Escanear almacenamiento y archivos grandes") {
                    if (!scanning) {
                        scanning = true
                        sel.clear()
                        scope.launch {
                            Store.scan = withContext(Dispatchers.IO) { scan() }
                            scanning = false
                        }
                    }
                }
            }
        }
        if (scanning) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }

        res?.let { r ->
            item { Title("Almacenamiento por tipo") }
            item { Text("${r.count} archivos analizados", fontSize = 12.sp) }
            val mx = (r.byCat.maxOfOrNull { it.second } ?: 1L).coerceAtLeast(1L)
            items(r.byCat, key = { "cat" + it.first }) { (name, bytes) ->
                Column {
                    Row(Modifier.fillMaxWidth()) {
                        Text("${iconOf(name)} $name", Modifier.weight(1f))
                        Text(fmt(bytes))
                    }
                    AnimBar(bytes.toFloat() / mx)
                }
            }

            item { Title("Archivos") }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FILTERS.forEach { f ->
                        if (filter == f) Button({ filter = f }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(f, fontSize = 12.sp) }
                        else OutlinedButton({ filter = f }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(f, fontSize = 12.sp) }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button({ sel.clear(); sel.addAll(rows.filter { it.suggest }.map { it.path }) }) { Text("Seleccionar sugeridos") }
                    Spacer(Modifier.width(8.dp))
                    TextButton({ sel.clear() }) { Text("Ninguno") }
                }
            }
            item { Text("Sugeridos = APK, actualizaciones y temporales. Duplicados, descargas viejas y archivos grandes los eliges tú.", fontSize = 11.sp) }
            if (rows.isEmpty()) item { Text("Nada en esta categoría. 👍") }
            items(rows, key = { it.path }) { f ->
                Row(Modifier.fillMaxWidth().clickable { preview = f }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(f.path in sel, { c -> if (c) sel.add(f.path) else sel.remove(f.path) })
                    FileThumb(f.path)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(File(f.path).name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                        Text("${f.kind} · ${fmt(f.bytes)}", fontSize = 11.sp)
                        Text("${File(f.path).parent}", fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            item {
                Button({ confirm = true }, Modifier.fillMaxWidth(), enabled = sel.isNotEmpty()) {
                    Text("Borrar ${sel.size} seleccionados (${fmt(selBytes)})")
                }
            }
        }

        item { Title("Apps sin usar (30+ días)") }
        item { Text("Según el registro de Android. Si no las necesitas, desinstalarlas libera espacio y quita procesos.", fontSize = 12.sp) }
        if (apps == null) item { Text("Analizando…") } else items(old, key = { "u" + it.pkg }) { AppCard(it) }

        item { Title("Apps que más ocupan") }
        item {
            Text(
                if (shiz) "Con Shizuku puedes limpiar la caché de cada app desde su tarjeta (🧹 Caché)."
                else "Android no deja que una app borre la caché de otras sin root: abre 'Info' → Almacenamiento → Borrar caché. (Con Shizuku sí se puede.)",
                fontSize = 12.sp
            )
        }
        if (apps == null) {
            item { Text("Analizando…") }
        } else {
            items(apps.sortedByDescending { it.totalMb }.take(25), key = { "s" + it.pkg }) { AppCard(it) }
            item { Title("Apps con más caché") }
            items(apps.sortedByDescending { it.cacheMb }.take(15), key = { "c" + it.pkg }) { AppCard(it) }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    preview?.let { f ->
        PreviewDialog(
            f, f.path in sel,
            { if (f.path in sel) sel.remove(f.path) else sel.add(f.path) },
            { preview = null }
        )
    }

    if (confirm) KDialog(
        "🗑", "¿Borrar ${sel.size} archivos?",
        "Se liberan ${fmt(selBytes)}. Esta acción es permanente. En los duplicados se conserva el más antiguo; revisa la lista antes de confirmar.",
        "Borrar",
        {
            var n = 0
            sel.forEach { if (File(it).delete()) n++ }
            Store.scan = Store.scan?.let { r -> r.copy(rows = r.rows.filter { File(it.path).exists() }) }
            sel.clear()
            confirm = false
            toast(ctx, "Listo: $n archivos borrados")
        },
        { confirm = false },
        "Cancelar", true
    )
}
