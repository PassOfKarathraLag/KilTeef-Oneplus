package com.kilteef.oneplus

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

@Composable
fun Avanzado() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shiz = LocalShiz.current
    var alive by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var cmd by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var top by remember { mutableStateOf<List<CpuProc>?>(null) }
    var temps by remember { mutableStateOf<List<Temp>?>(null) }
    var svcs by remember { mutableStateOf<List<Pair<String, Int>>?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            alive = withContext(Dispatchers.IO) { Sh.shizukuAlive() }
            delay(1500)
        }
    }

    fun exec(c: String, done: (String) -> Unit) {
        if (busy) return
        busy = true
        scope.launch {
            val r = Sh.runIO(c)
            done(r)
            busy = false
        }
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Funciones avanzadas (sin root)", style = MaterialTheme.typography.headlineSmall)
        val green = Color(0xFF66BB6A)
        var openA by remember { mutableStateOf(true) }
        var openB by remember { mutableStateOf(false) }
        var openC by remember { mutableStateOf(false) }
        var openD by remember { mutableStateOf(false) }
        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        Appear(0) {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Pulse(if (shiz) green else Color(0xFF9E9E9E))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            if (shiz) "Acceso avanzado: LISTO ✅" else "Acceso avanzado: sin activar",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            if (Adb.connected()) "Conectado por ADB integrado"
                            else if (Sh.shizukuGranted()) "Conectado por Shizuku"
                            else "Elige un método para activarlo",
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
        if (!shiz) {
            Fold("Método 1 · ADB integrado (sin instalar nada)", openA, { openA = !openA }) {
                if (!Adb.supported) {
                    Text("Esta compilación no incluye ADB integrado. Usa el método 2 o 3.", fontSize = 12.sp)
                } else {
                    Text(
                        "1) Conéctate a una red Wi-Fi (la depuración inalámbrica no funciona solo con datos móviles).\n" +
                            "2) Ajustes → Acerca del teléfono → toca 7 veces «Número de compilación».\n" +
                            "3) Ajustes → Sistema → Opciones de desarrollador → activa «Depuración inalámbrica».\n" +
                            "4) Toca «Empezar vinculación» aquí abajo y, en Ajustes, «Vincular dispositivo con código de vinculación».\n" +
                            "5) Cuando llegue el aviso de KilTeef, toca «Escribir código» y escribe los 6 dígitos que ves en pantalla.",
                        fontSize = 12.sp
                    )
                    Btn("▶ Empezar vinculación") {
                        if (ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        Adb.begin(ctx)
                        go(ctx, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                    }
                    Text("Estado: ${Adb.status}", fontSize = 12.sp)
                    Btn("🔄 Reconectar (si ya vinculaste antes)") {
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) { Adb.reconnect(ctx) }
                            toast(ctx, if (ok) "Listo: conectado" else "No se pudo conectar. ¿Está activa la depuración inalámbrica y el Wi-Fi?")
                        }
                    }
                }
            }
            Fold("Método 2 · Shizuku", openB, { openB = !openB }) {
                Text(
                    "Shizuku es una app gratuita que presta a KilTeef permisos de ADB sin root.\n" +
                        "1) Instálala. 2) Actívala con «Depuración inalámbrica» (o con la PC). 3) Vuelve aquí y toca «Dar permiso».",
                    fontSize = 12.sp
                )
                if (!alive) {
                    Btn("Descargar Shizuku (Google Play)") {
                        tryStart(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api")))
                    }
                    Btn("Abrir Shizuku") {
                        val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                        if (i == null || !tryStart(ctx, i)) toast(ctx, "Shizuku no está instalado")
                    }
                } else {
                    Btn("Dar permiso a KilTeef") { Sh.ask() }
                }
            }
            Fold("Método 3 · Con la PC y un cable USB", openC, { openC = !openC }) {
                Text(
                    "Funciona aunque no tengas Wi-Fi. Necesitas la herramienta gratuita «adb» en la PC.\n" +
                        "1) Activa «Depuración USB» en Opciones de desarrollador y conecta el cable (acepta la huella).\n" +
                        "2) Instala Shizuku en el teléfono y ejecuta en la PC:\n" +
                        "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh\n" +
                        "3) Vuelve aquí y toca «Dar permiso» (método 2). Dura hasta que reinicies el teléfono.",
                    fontSize = 12.sp
                )
            }
            Fold("¿No te deja? Causas comunes", openD, { openD = !openD }) {
                Text(
                    "• «Depuración inalámbrica» necesita Wi-Fi conectado: con datos móviles no aparece o se apaga.\n" +
                        "• Se apaga sola al cambiar de red o reiniciar: vuelve a activarla y pulsa «Reconectar».\n" +
                        "• El aviso del código solo funciona mientras Ajustes muestra el cuadro «Código de vinculación Wi-Fi»; si lo cierras, el código deja de servir.\n" +
                        "• Si el botón de Opciones de desarrollador no aparece, toca 7 veces «Número de compilación».\n" +
                        "• Si nada funciona, usa el método 3 (cable USB).",
                    fontSize = 12.sp
                )
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (!shiz) Text("Las herramientas de abajo se activan cuando el acceso avanzado esté listo.", fontSize = 12.sp)

        Text("Herramientas", style = MaterialTheme.typography.titleMedium)
        Btn("🧹 Limpiar caché de TODAS las apps", enabled = shiz && !busy) {
            val before = snap(ctx).stoUsedGb
            exec("pm trim-caches 999G") {
                toast(ctx, "Caché limpiada · liberado ≈ %.2f GB".format(maxOf(0f, before - snap(ctx).stoUsedGb)))
            }
        }
        Btn("⚙️ Optimizar apps en segundo plano (ART)", enabled = shiz && !busy) {
            exec("cmd package bg-dexopt-job") { toast(ctx, "Optimización iniciada; el sistema la termina solo") }
        }
        Btn("📊 Procesos con más CPU (real)", enabled = shiz && !busy) {
            exec("dumpsys cpuinfo") { top = parseCpu(it) }
        }
        top?.let { l ->
            if (l.isEmpty()) Text("Sin datos: el formato de esta versión de Android es distinto.", fontSize = 12.sp)
            val mx = (l.maxOfOrNull { it.pct } ?: 1f).coerceAtLeast(1f)
            l.forEach { p ->
                Column {
                    Text("${labelOf(ctx, p.name)} · %.1f %%".format(p.pct), fontSize = 12.sp)
                    AnimBar(p.pct / mx)
                }
            }
        }
        Btn("🌡 Temperaturas internas (CPU, GPU, piel)", enabled = shiz && !busy) {
            exec("dumpsys thermalservice") { temps = parseTemps(it) }
        }
        temps?.let { l ->
            if (l.isEmpty()) Text("Sin datos de sensores.", fontSize = 12.sp)
            l.forEach { Text("${it.name}: %.1f °C".format(it.c), fontSize = 13.sp) }
        }
        Btn("🧩 Servicios en ejecución por app", enabled = shiz && !busy) {
            exec("dumpsys activity services") { svcs = parseServices(it) }
        }
        svcs?.let { l ->
            if (l.isEmpty()) Text("Sin datos.", fontSize = 12.sp)
            l.forEach { Text("${labelOf(ctx, it.first)} · ${it.second} servicio(s)", fontSize = 13.sp) }
        }

        Text("Animaciones del sistema", style = MaterialTheme.typography.titleMedium)
        Text("Reducirlas hace que el teléfono se sienta más rápido.", fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Apagar" to "0", "Rápidas" to "0.5", "Normal" to "1").forEach { (n, v) ->
                OutlinedButton(
                    {
                        exec("settings put global window_animation_scale $v; settings put global transition_animation_scale $v; settings put global animator_duration_scale $v") {
                            toast(ctx, "Animaciones: $n")
                        }
                    },
                    Modifier.weight(1f), enabled = shiz && !busy, contentPadding = PaddingValues(4.dp)
                ) { Text(n, fontSize = 12.sp) }
            }
        }

        Text("Consola (comandos de shell)", style = MaterialTheme.typography.titleMedium)
        Text("Corre con permisos de ADB. No pegues comandos de fuentes que no conozcas.", fontSize = 11.sp)
        OutlinedTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), label = { Text("Ej: dumpsys battery") }, singleLine = true)
        Btn("▶ Ejecutar", enabled = shiz && !busy && cmd.isNotBlank()) {
            exec(cmd) { out = it.takeLast(4000) }
        }
        if (out.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Text(out, Modifier.padding(10.dp), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
