package com.kilteef.oneplus

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

data class MsgItem(val id: Long, val text: String, val kind: Int)

object Msg {
    var cur by mutableStateOf<MsgItem?>(null)
}

private class MsgHolder {
    var v: MsgItem? = null
}

/** Aviso dentro de la app (reemplaza al Toast del sistema): color según el tipo. */
fun toast(ctx: Context, msg: String) {
    val low = msg.lowercase()
    val kind = when {
        low.startsWith("error") || low.contains("no se pudo") || low.contains("no permite") ||
            low.contains("no hay app") || low.contains("no está instalado") -> 2
        low.contains("listo") || low.contains("limpiada") || low.contains("borrados") ||
            low.contains("orden enviada") || low.contains("liberado") || low.contains("restringida") -> 1
        else -> 0
    }
    Msg.cur = MsgItem(System.nanoTime(), msg, kind)
}

@Composable
fun BannerHost(modifier: Modifier = Modifier) {
    val m = Msg.cur
    val holder = remember { MsgHolder() }
    if (m != null) holder.v = m
    LaunchedEffect(m?.id) {
        if (m != null) {
            delay(4500)
            if (Msg.cur?.id == m.id) Msg.cur = null
        }
    }
    AnimatedVisibility(
        m != null, modifier = modifier,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut()
    ) {
        val item = holder.v
        if (item != null) {
            val icon = when (item.kind) {
                1 -> "✅"
                2 -> "⚠️"
                else -> "ℹ️"
            }
            val bg = when (item.kind) {
                1 -> Color(0xFF1B5E20)
                2 -> Color(0xFF8E2A1B)
                else -> Color(0xFF263238)
            }
            Card(
                Modifier.padding(16.dp).fillMaxWidth().clickable { Msg.cur = null },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = bg),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(icon, fontSize = 20.sp)
                    Spacer(Modifier.width(10.dp))
                    Text(item.text, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

/** Diálogo redondeado con icono, título claro y botón principal. */
@Composable
fun KDialog(
    icon: String, title: String, text: String, confirm: String,
    onConfirm: () -> Unit, onDismiss: () -> Unit,
    dismiss: String = "Cancelar", destructive: Boolean = false
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        icon = { Text(icon, fontSize = 36.sp) },
        title = { Text(title) },
        text = { Text(text, fontSize = 14.sp) },
        confirmButton = {
            Button(
                onConfirm,
                colors = if (destructive) ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F), contentColor = Color.White)
                else ButtonDefaults.buttonColors()
            ) { Text(confirm) }
        },
        dismissButton = { TextButton(onDismiss) { Text(dismiss) } }
    )
}

/** Tarjeta plegable (toca el título para abrir/cerrar). */
@Composable
fun Fold(title: String, open: Boolean, onToggle: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth().clickable { onToggle() }, verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Text(if (open) "▲" else "▼")
            }
            AnimatedVisibility(open) {
                Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
            }
        }
    }
}

@Composable
fun Pill(text: String) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) { Text(text, fontSize = 11.sp) }
}

@Composable
fun SetupRow(ok: Boolean, text: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(if (ok) "✅" else "⭕")
        Spacer(Modifier.width(8.dp))
        Text(text, Modifier.weight(1f), fontSize = 13.sp)
        if (!ok) TextButton(onClick) { Text(action) }
    }
}
