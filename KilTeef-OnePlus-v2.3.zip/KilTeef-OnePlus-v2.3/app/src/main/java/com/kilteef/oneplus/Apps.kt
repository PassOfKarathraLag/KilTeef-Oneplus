package com.kilteef.oneplus

import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- 2. Procesos ----------

@Composable
fun Procesos(apps: List<AppRow>?, reload: () -> Unit) {
    val ctx = LocalContext.current
    var sys by remember { mutableStateOf(false) }
    val granted = hasUsage(ctx)
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Title("Procesos y segundo plano") }
        if (!granted) item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Info("Falta un permiso", "Activa 'Acceso de uso' para KilTeef. Sin él Android no me deja ver qué apps están activas.")
                Btn("Dar acceso de uso") { go(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS, ctx.packageName) }
                Btn("Ya lo activé · actualizar") { reload() }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(sys, { sys = it })
                Spacer(Modifier.width(8.dp))
                Text("Mostrar apps del sistema", fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                TextButton({ reload() }) { Text("Actualizar") }
            }
        }
        if (apps == null) {
            item { Text("Analizando…") }
        } else {
            val list = apps.filter { sys || !it.system }
            val active = list.filter { it.fgsOn }
            item { Text("🔴 Servicios en primer plano activos (${active.size})", style = MaterialTheme.typography.titleMedium) }
            item { Text("Son las apps que mantienen un servicio corriendo (suelen mostrar notificación). Cálculo aproximado de las últimas 24 h.", fontSize = 11.sp) }
            items(active, key = { "a" + it.pkg }) { AppCard(it) }
            item { Text("⏱ Más usadas en 24 h", style = MaterialTheme.typography.titleMedium) }
            val usedList = list.filter { it.fgMin > 0 || it.fgs > 0 }.sortedByDescending { it.fgMin }.take(40)
            val topMin = (usedList.maxOfOrNull { it.fgMin } ?: 1L).coerceAtLeast(1L).toFloat()
            items(usedList, key = { "b" + it.pkg }) { AppCard(it, it.fgMin / topMin) }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

