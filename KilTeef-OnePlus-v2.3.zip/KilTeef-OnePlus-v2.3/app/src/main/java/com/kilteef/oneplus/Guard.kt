package com.kilteef.oneplus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

/** Historial de avisos (se guarda en el teléfono, máx. 60). */
object Events {
    val items = mutableStateListOf<String>()
    private var ready = false

    fun init(ctx: Context) {
        if (ready) return
        ready = true
        val s = ctx.getSharedPreferences("kilteef", Context.MODE_PRIVATE).getString("events", "") ?: ""
        items.addAll(s.split("\n").filter { it.isNotBlank() })
    }

    fun add(ctx: Context, msg: String) {
        init(ctx)
        val t = java.text.SimpleDateFormat("dd/MM HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        items.add(0, "$t  " + msg.replace("\n", " "))
        while (items.size > 60) items.removeAt(items.size - 1)
        save(ctx)
    }

    fun clear(ctx: Context) {
        items.clear()
        save(ctx)
    }

    private fun save(ctx: Context) {
        ctx.getSharedPreferences("kilteef", Context.MODE_PRIVATE).edit()
            .putString("events", items.joinToString("\n")).apply()
    }
}

/** Vigila si alguna app abre la cámara o el micrófono. Android no dice QUÉ app: se dan pistas. */
class GuardService : Service() {
    companion object {
        val running = mutableStateOf(false)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val camOpen = HashSet<String>()
    private val lastAlert = HashMap<String, Long>()
    private var started = false
    private lateinit var cm: CameraManager
    private lateinit var am: AudioManager

    private val camCb = object : CameraManager.AvailabilityCallback() {
        override fun onCameraUnavailable(cameraId: String) {
            camOpen.add(cameraId)
            // Espera 2,5 s: filtra usos muy cortos (p. ej. desbloqueo facial)
            handler.postDelayed({
                if (cameraId in camOpen) report("📷 Cámara ${camName(cameraId)}", "android.permission.CAMERA")
            }, 2500)
        }

        override fun onCameraAvailable(cameraId: String) {
            camOpen.remove(cameraId)
        }
    }

    private val micCb = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
            if (!configs.isNullOrEmpty()) {
                handler.postDelayed({
                    if (am.activeRecordingConfigurations.isNotEmpty()) report("🎤 Micrófono", "android.permission.RECORD_AUDIO")
                }, 2000)
            }
        }
    }

    private fun camName(id: String): String = try {
        when (cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)) {
            CameraCharacteristics.LENS_FACING_FRONT -> "frontal"
            CameraCharacteristics.LENS_FACING_BACK -> "trasera"
            else -> "externa"
        }
    } catch (e: Exception) { "id $id" }

    private fun report(kind: String, perm: String) {
        val now = System.currentTimeMillis()
        if (now - (lastAlert[kind] ?: 0L) < 30_000) return
        lastAlert[kind] = now
        val fg = foregroundPkg(this)
        val pm = packageManager
        val sus = fgsActive(this)
            .filter { it != packageName && it != fg && pm.checkPermission(perm, it) == PackageManager.PERMISSION_GRANTED }
            .take(4).map { labelOf(this, it) }
        val screenOff = !(getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        val fgName = if (fg != null) labelOf(this, fg) else "no se sabe"
        val hora = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        var msg = "$kind en uso · " + (if (screenOff) "PANTALLA APAGADA · " else "") + "app al frente: $fgName"
        if (sus.isNotEmpty()) msg += " · con servicio activo y permiso: " + sus.joinToString()
        Events.add(this, msg)
        if (screenOff || sus.isNotEmpty()) {
            val short = if (screenOff) "Con la pantalla apagada · $hora" else "Posible responsable: ${sus.first()}"
            val detail = "Se detectó a las $hora " + (if (screenOff) "con la pantalla apagada." else "con la pantalla encendida.") +
                "\n\nApp al frente: $fgName" +
                (if (sus.isNotEmpty()) "\nApps con permiso y servicio activo: " + sus.joinToString() else "") +
                "\n\nToca para abrir Privacidad y revisar o quitar sus permisos."
            alert("⚠ $kind en uso", short, detail)
        }
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).putExtra("tab", 4)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun alert(title: String, short: String, detail: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val open = openApp()
        val n = Notification.Builder(this, "alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setColor(0xFFFF7043.toInt())
            .setContentTitle(title)
            .setContentText(short)
            .setStyle(Notification.BigTextStyle().bigText(detail))
            .setCategory(Notification.CATEGORY_STATUS)
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Revisar permisos", open).build())
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt() + 10, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("guard", "Vigilante activo", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alerts", "Alertas de cámara y micrófono", NotificationManager.IMPORTANCE_HIGH))
        val stop = PendingIntent.getService(this, 3, Intent(this, GuardService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "guard")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setColor(0xFF66BB6A.toInt())
            .setContentTitle("🛡 Vigilante activo")
            .setContentText("Te aviso si una app usa la cámara o el micrófono")
            .setOngoing(true)
            .setContentIntent(openApp())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Apagar", stop).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (!started) {
            started = true
            cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            cm.registerAvailabilityCallback(mainExecutor, camCb)
            am.registerAudioRecordingCallback(micCb, handler)
            running.value = true
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (started) {
            cm.unregisterAvailabilityCallback(camCb)
            am.unregisterAudioRecordingCallback(micCb)
        }
        handler.removeCallbacksAndMessages(null)
        running.value = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
