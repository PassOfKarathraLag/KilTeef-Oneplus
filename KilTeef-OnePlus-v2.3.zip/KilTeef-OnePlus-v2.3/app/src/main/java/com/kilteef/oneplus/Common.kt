package com.kilteef.oneplus

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.provider.Settings
import android.util.LruCache
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.ceil

/** true cuando hay acceso avanzado (Shizuku o ADB integrado). */
val LocalShiz = compositionLocalOf { false }

/** Estado que sobrevive al cambiar de pestaña. */
object Store {
    var scan by mutableStateOf<ScanResult?>(null)
    var tabRequest by mutableIntStateOf(-1)
}

fun fmtMin(m: Long): String = if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"

// ---------- animaciones ----------

@Composable
fun Appear(i: Int = 0, content: @Composable () -> Unit) {
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(50L * i.coerceAtMost(10))
        v = true
    }
    AnimatedVisibility(v, enter = fadeIn(tween(450)) + slideInVertically { it / 5 }) { content() }
}

/** Barra de progreso redondeada y animada. */
@Composable
fun AnimBar(p: Float, modifier: Modifier = Modifier.fillMaxWidth(), color: Color = Mint) {
    val a by animateFloatAsState(p.coerceIn(0f, 1f), tween(700), label = "bar")
    Box(modifier.height(8.dp).clip(RoundedCornerShape(4.dp)).background(Line)) {
        Box(
            Modifier.fillMaxHeight().fillMaxWidth(a).clip(RoundedCornerShape(4.dp))
                .background(Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.65f))))
        )
    }
}

@Composable
fun Pulse(color: Color, size: Int = 12) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable<Float>(tween<Float>(900), RepeatMode.Reverse), label = "alpha")
    Box(Modifier.size(size.dp).alpha(a).background(color, CircleShape))
}

// ---------- piezas visuales ----------

@Composable
fun Info(title: String, body: String, color: Color = Color.Unspecified) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = Dim)
            Text(body, style = MaterialTheme.typography.titleMedium, color = if (color == Color.Unspecified) Txt else color)
        }
    }
}

@Composable
fun Btn(text: String, enabled: Boolean = true, onClick: () -> Unit) =
    FilledTonalButton(
        onClick, Modifier.fillMaxWidth().heightIn(min = 48.dp), enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.filledTonalButtonColors(containerColor = CardHi, contentColor = Txt)
    ) { Text(text) }

@Composable
fun PillButton(text: String, modifier: Modifier = Modifier.fillMaxWidth(), onClick: () -> Unit) =
    Button(
        onClick, modifier, shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Color(0xFF00281A))
    ) { Text(text, fontWeight = FontWeight.SemiBold) }

@Composable
fun Title(text: String) =
    Row(Modifier.padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(22.dp).clip(RoundedCornerShape(2.dp)).background(Mint))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.titleLarge)
    }

@Composable
fun Tile(icon: String, title: String, sub: String?, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) { Text(icon, fontSize = 20.sp) }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (sub != null) Text(sub, fontSize = 11.sp, color = Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

fun tempLabel(t: Float) = when {
    t < 35 -> "Normal"
    t < 40 -> "Tibia"
    t < 43 -> "Caliente"
    else -> "Muy caliente"
}

fun tempColor(t: Float) = when {
    t < 40 -> Mint
    t < 43 -> Amber
    else -> Coral
}

fun push(l: MutableList<Float>, v: Float) {
    l.add(v)
    if (l.size > 90) l.removeAt(0)
}

/** Gráfica de línea con relleno degradado. */
@Composable
fun Chart(h: List<Float>, color: Color) {
    Card(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(100.dp).padding(14.dp)) {
            if (h.size < 2) return@Canvas
            val lo = h.min() - 1f
            val hi = h.max() + 1f
            val line = Path()
            val fill = Path()
            fill.moveTo(0f, size.height)
            h.forEachIndexed { i, v ->
                val x = size.width * i / (h.size - 1)
                val y = size.height * (1f - (v - lo) / (hi - lo))
                if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
                fill.lineTo(x, y)
            }
            fill.lineTo(size.width, size.height)
            fill.close()
            drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent)))
            drawPath(line, color, style = Stroke(width = 5f))
        }
    }
}

/** Matriz de puntos tipo ecualizador (0–100 %): verde → ámbar → coral. */
@Composable
fun DotMatrix(values: List<Float>, modifier: Modifier = Modifier, cols: Int = 30, rows: Int = 8) {
    Canvas(modifier.fillMaxWidth().height(110.dp)) {
        val cw = size.width / cols
        val ch = size.height / rows
        val r = minOf(cw, ch) * 0.36f
        val data = if (values.size >= cols) values.takeLast(cols) else List(cols - values.size) { 0f } + values
        for (c in 0 until cols) {
            val lit = ceil(data[c].coerceIn(0f, 100f) / 100f * rows).toInt()
            for (k in 0 until rows) {
                val level = (k + 1f) / rows
                val col = when {
                    k >= lit -> Color(0xFF1E2935)
                    level > 0.75f -> Coral
                    level > 0.5f -> Amber
                    else -> Mint
                }
                drawCircle(col, r, Offset(cw * (c + 0.5f), size.height - ch * (k + 0.5f)))
            }
        }
    }
}

// ---------- iconos de apps ----------

object IconCache {
    private val cache = LruCache<String, Bitmap>(150)
    fun get(ctx: Context, pkg: String): Bitmap? {
        cache.get(pkg)?.let { return it }
        return try {
            val b = ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
            cache.put(pkg, b)
            b
        } catch (e: Exception) { null }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, pkg) { value = withContext(Dispatchers.IO) { IconCache.get(ctx, pkg) } }
    Box(Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(CardHi), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize()) else Text("📦", fontSize = 18.sp)
    }
}

@Composable
fun AppCard(a: AppRow, frac: Float = -1f) {
    val ctx = LocalContext.current
    val shiz = LocalShiz.current
    val scope = rememberCoroutineScope()
    val pad = PaddingValues(horizontal = 6.dp)
    Appear {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(a.pkg)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(a.pkg, fontSize = 10.sp, color = Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(fmtMin(a.fgMin), style = MaterialTheme.typography.titleSmall, color = Mint)
                }
                if (frac >= 0f) AnimBar(frac)
                Text(
                    "Último uso: ${ago(maxOf(a.last, a.lastAny))}" +
                        (if (a.fgs > 0) " · servicios: ${a.fgs}" else "") +
                        " · ${a.totalMb} MB (caché ${a.cacheMb} MB)",
                    fontSize = 12.sp, color = Dim
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton({
                        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(a.pkg)
                        toast(ctx, "Orden enviada a ${a.name}")
                    }, contentPadding = pad) { Text("Detener", fontSize = 13.sp) }
                    TextButton({ go(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, a.pkg) }, contentPadding = pad) { Text("Info", fontSize = 13.sp) }
                    TextButton({ openPerms(ctx, a.pkg) }, contentPadding = pad) { Text("Permisos", fontSize = 13.sp) }
                    if (!a.system) TextButton({ go(ctx, Intent.ACTION_DELETE, a.pkg) }, contentPadding = pad) { Text("Desinstalar", fontSize = 13.sp) }
                }
                if (shiz) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton({
                            scope.launch { toast(ctx, "${a.name}: " + Sh.runIO("am force-stop ${a.pkg}").ifBlank { "detenida" }.take(80)) }
                        }, contentPadding = pad) { Text("⛔ Parar", fontSize = 13.sp) }
                        TextButton({
                            scope.launch {
                                Sh.runIO("cmd appops set ${a.pkg} RUN_ANY_IN_BACKGROUND ignore; am set-standby-bucket ${a.pkg} restricted")
                                toast(ctx, "${a.name}: restringida en segundo plano")
                            }
                        }, contentPadding = pad) { Text("🔒 Restringir", fontSize = 13.sp) }
                        TextButton({
                            scope.launch { toast(ctx, "${a.name}: " + Sh.runIO("pm clear --cache-only ${a.pkg}").take(80)) }
                        }, contentPadding = pad) { Text("🧹 Caché", fontSize = 13.sp) }
                    }
                }
            }
        }
    }
}
