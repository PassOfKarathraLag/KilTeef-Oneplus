package com.kilteef.oneplus

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun healthText(h: Int) = when (h) {
    2 -> "Buena"
    3 -> "Sobrecalentada"
    4 -> "Muerta"
    5 -> "Sobrevoltaje"
    6 -> "Falla"
    7 -> "Fría"
    else -> "Desconocida"
}

@Composable
fun Inicio(apps: List<AppRow>?, goTab: (Int) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shiz = LocalShiz.current
    var s by remember { mutableStateOf(snap(ctx)) }
    var cpu by remember { mutableFloatStateOf(0f) }
    var coreInfo by remember { mutableStateOf("") }
    val cpuH = remember { mutableStateListOf<Float>() }
    var busy by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            s = snap(ctx)
            val cores = withContext(Dispatchers.IO) { readCores() }
            val ok = cores.filter { it.cur > 0 && it.max > 0 }
            cpu = if (ok.isEmpty()) 0f else ok.map { it.cur * 100f / it.max }.average().toFloat()
            coreInfo = if (cores.isEmpty()) "" else "${cores.size} núcleos · hasta ${(cores.maxOfOrNull { it.max } ?: 0L) / 1000} MHz"
            push(cpuH, cpu)
            delay(1500)
        }
    }
    val (score, tips) = advise(ctx, s, apps, shiz)
    val anim by animateFloatAsState(score / 100f, tween(1200), label = "score")
    val col = when {
        score >= 80 -> Mint
        score >= 55 -> Amber
        else -> Coral
    }
    val verdict = when {
        score >= 80 -> "Tu teléfono está en buen estado"
        score >= 55 -> "Hay cosas por mejorar"
        else -> "Necesita mantenimiento"
    }
    val usageOk = hasUsage(ctx)
    val filesOk = Environment.isExternalStorageManager()
    val notifOk = ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val missing = listOf(usageOk, filesOk, notifOk).count { !it }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val stoPct = (s.stoUsedGb * 100 / s.stoTotalGb.coerceAtLeast(1f)).toInt()
    val screenMin = (apps ?: emptyList()).sumOf { it.fgMin }
    val used = (apps ?: emptyList()).filter { !it.system && it.fgMin > 0 }.sortedByDescending { it.fgMin }

    if (help) KDialog(
        "🔓", "Desbloquear permisos",
        "Android bloquea ciertos permisos a las apps instaladas fuera de Google Play.\n\n1) Toca «Abrir Info de la app».\n2) Menú ⋮ (arriba a la derecha) → «Permitir ajustes restringidos» y confirma.\n3) Vuelve y da el permiso.",
        "Abrir Info de la app",
        { go(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, ctx.packageName); help = false },
        { help = false }, "Cerrar"
    )

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("KilTeef", style = MaterialTheme.typography.headlineSmall)
                Text("v2.3 · ${Build.MODEL} · Android ${Build.VERSION.RELEASE}", fontSize = 12.sp, color = Dim)
            }
            Pill(if (shiz) "⚡ Acceso avanzado" else "Modo básico")
        }

        if (missing > 0) {
            Appear(1) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF12303A))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("🧭 Configuración inicial (${3 - missing}/3)", style = MaterialTheme.typography.titleMedium)
                        Text("Da estos permisos una sola vez para que todo funcione.", fontSize = 12.sp, color = Dim)
                        SetupRow(usageOk, "Acceso de uso (ver apps activas)", "Dar") { go(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS, ctx.packageName) }
                        SetupRow(filesOk, "Acceso a todos los archivos (limpieza)", "Dar") { go(ctx, Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, ctx.packageName) }
                        SetupRow(notifOk, "Notificaciones (avisos del vigilante)", "Dar") { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                        TextButton({ help = true }) { Text("¿Android dice «se negó el acceso»?") }
                    }
                }
            }
        }

        // ---- Salud ----
        Appear(0) {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF123A3F), CardBg)))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.fillMaxSize()) {
                                val w = 12.dp.toPx()
                                val tl = Offset(w / 2, w / 2)
                                val sz = Size(size.width - w, size.height - w)
                                drawArc(Color(0x22FFFFFF), -90f, 360f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                                drawArc(Brush.sweepGradient(listOf(Cyan, col, Cyan)), -90f, 360f * anim, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                            }
                            Text("${(anim * 100).toInt()}", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = col)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Salud del teléfono", style = MaterialTheme.typography.labelLarge, color = Dim)
                            Text(verdict, style = MaterialTheme.typography.titleMedium)
                            Text("${tips.count { it.level > 0 }} sugerencias", fontSize = 12.sp, color = Dim)
                        }
                    }
                    PillButton(if (busy) "Optimizando…" else "⚡ Optimizar ahora") {
                        if (!busy) {
                            busy = true
                            scope.launch {
                                val before = snap(ctx)
                                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                                (apps ?: emptyList()).filter { !it.system && it.pkg != ctx.packageName }
                                    .forEach { am.killBackgroundProcesses(it.pkg) }
                                if (shiz) Sh.runIO("pm trim-caches 999G")
                                delay(1500)
                                val after = snap(ctx)
                                toast(ctx, "Listo: RAM ${before.ramUsedMb} → ${after.ramUsedMb} MB" + (if (shiz) " · caché limpiada" else ""))
                                busy = false
                            }
                        }
                    }
                }
            }
        }

        // ---- CPU en vivo ----
        Appear(1) {
            Card(Modifier.fillMaxWidth().clickable { goTab(1) }) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Uso de CPU (estimado)", style = MaterialTheme.typography.labelLarge, color = Dim)
                            Text("%.0f %%".format(cpu), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        }
                        Pulse(if (cpu > 75f) Coral else if (cpu > 45f) Amber else Mint)
                    }
                    DotMatrix(cpuH)
                    if (coreInfo.isNotEmpty()) Text(coreInfo, fontSize = 12.sp, color = Dim)
                }
            }
        }

        // ---- Almacenamiento y temperatura ----
        Appear(2) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(Modifier.weight(1f)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Almacenamiento", style = MaterialTheme.typography.labelLarge, color = Dim)
                        Text("$stoPct%", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("%.0f / %.0f GB".format(s.stoUsedGb, s.stoTotalGb), fontSize = 12.sp, color = Dim)
                        AnimBar(stoPct / 100f, color = if (stoPct >= 90) Coral else if (stoPct >= 80) Amber else Mint)
                        Spacer(Modifier.height(2.dp))
                        PillButton("Limpiar") { goTab(3) }
                    }
                }
                Card(Modifier.weight(1f)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Temperatura", style = MaterialTheme.typography.labelLarge, color = Dim, modifier = Modifier.weight(1f))
                            Pulse(tempColor(s.temp), 10)
                        }
                        Text("%.0f °C".format(s.temp), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = tempColor(s.temp))
                        Text("Batería ${s.pct}%" + (if (s.charging) " ⚡" else "") + " · ${healthText(s.health)}", fontSize = 12.sp, color = Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        AnimBar(s.temp / 60f, color = tempColor(s.temp))
                        Spacer(Modifier.height(2.dp))
                        PillButton("Controlar") { goTab(1) }
                    }
                }
            }
        }

        // ---- Uso de hoy ----
        Appear(3) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Uso de hoy", style = MaterialTheme.typography.labelLarge, color = Dim)
                            Text(fmtMin(screenMin), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                        TextButton({ goTab(2) }) { Text("Ver todo") }
                    }
                    if (apps == null) {
                        Text("Analizando…", fontSize = 12.sp, color = Dim)
                    } else if (used.isEmpty()) {
                        Text("Sin datos de uso: da el «Acceso de uso» en la configuración inicial.", fontSize = 12.sp, color = Dim)
                    } else {
                        val mx = used.first().fgMin.toFloat().coerceAtLeast(1f)
                        used.take(3).forEach { a ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AppIcon(a.pkg, 38.dp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(a.name, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    AnimBar(a.fgMin / mx)
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(fmtMin(a.fgMin), fontSize = 12.sp, color = Dim)
                            }
                        }
                    }
                }
            }
        }

        // ---- Accesos rápidos ----
        Appear(4) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile("⚙️", "CPU y calor", "%.0f %% ahora".format(cpu), Cyan, Modifier.weight(1f)) { goTab(1) }
                    Tile("📋", "Apps", apps?.let { "${it.size} instaladas" }, Violet, Modifier.weight(1f)) { goTab(2) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile("🧹", "Limpieza", "Archivos grandes", Amber, Modifier.weight(1f)) { goTab(3) }
                    Tile("🔒", "Privacidad", if (GuardService.running.value) "Vigilante activo" else "Vigilante apagado", Coral, Modifier.weight(1f)) { goTab(4) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile("🚀", "Acceso avanzado", if (shiz) "Listo ✅" else "Sin activar", Mint, Modifier.weight(1f)) { goTab(5) }
                    Tile("📱", "Pantalla", "Prueba línea verde", Cyan, Modifier.weight(1f)) { goTab(5) }
                }
            }
        }

        // ---- Sugerencias ----
        Text("Sugerencias (toca una para ir)", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp))
        tips.forEachIndexed { i, t ->
            Appear(i + 2) {
                Card(
                    Modifier.fillMaxWidth().clickable { goTab(t.tab) },
                    colors = CardDefaults.cardColors(
                        containerColor = when (t.level) {
                            2 -> Color(0xFF33191C)
                            1 -> Color(0xFF332A14)
                            else -> CardBg
                        }
                    )
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.icon, fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(t.title, style = MaterialTheme.typography.titleSmall)
                            Text(t.text, fontSize = 12.sp, color = Dim)
                        }
                    }
                }
            }
        }
        Info("Software", "${Build.MODEL} · Android ${Build.VERSION.RELEASE}\n${Build.DISPLAY}\nParche: ${Build.VERSION.SECURITY_PATCH}")
        Spacer(Modifier.height(16.dp))
    }
}
