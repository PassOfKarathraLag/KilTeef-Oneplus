package com.kilteef.oneplus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Cliente ADB propio (libadb-android): permite vincular y ejecutar comandos de shell sin Shizuku. */
class KilAdb(ctx: Context) : AbsAdbConnectionManager() {
    private val key: PrivateKey
    private val cert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val kf = File(ctx.filesDir, "adb_key.pk8")
        val cf = File(ctx.filesDir, "adb_cert.der")
        var k: PrivateKey? = null
        var c: Certificate? = null
        try {
            if (kf.exists() && cf.exists()) {
                k = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
                c = cf.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
            }
        } catch (e: Exception) {
            k = null
            c = null
        }
        if (k == null || c == null) {
            val gen = KeyPairGenerator.getInstance("RSA")
            gen.initialize(2048)
            val kp = gen.generateKeyPair()
            val name = X500Name("CN=KilTeef")
            val now = System.currentTimeMillis()
            val builder = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(now), Date(now - 86_400_000L), Date(now + 3_650L * 86_400_000L), name, kp.public
            )
            val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
            val made = JcaX509CertificateConverter().getCertificate(builder.build(signer))
            kf.writeBytes(kp.private.encoded)
            cf.writeBytes(made.encoded)
            k = kp.private
            c = made
        }
        key = requireNotNull(k)
        cert = requireNotNull(c)
    }

    override fun getPrivateKey(): PrivateKey = key
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "KilTeef"
}

object Adb {
    val supported = true
    var status by mutableStateOf("Sin vincular")
    @Volatile private var mgr: KilAdb? = null

    private fun m(ctx: Context): KilAdb = mgr ?: synchronized(this) {
        mgr ?: KilAdb(ctx.applicationContext).also { mgr = it }
    }

    fun connected(): Boolean = try { mgr?.isConnected == true } catch (e: Throwable) { false }

    fun pair(ctx: Context, host: String, port: Int, code: String): Boolean =
        try { m(ctx).pair(host, port, code) } catch (e: Throwable) { false }

    fun connect(ctx: Context, host: String, port: Int): Boolean =
        try { m(ctx).connect(host, port) } catch (e: Throwable) { false }

    fun run(cmd: String): String {
        val mg = mgr ?: return "ADB integrado no conectado"
        return try {
            val st = mg.openStream("shell:$cmd")
            val out = st.openInputStream().bufferedReader().readText()
            try { st.close() } catch (e: Exception) { }
            out.trim()
        } catch (e: Throwable) {
            "Error: " + e.message
        }
    }

    /** Arranca el asistente de vinculación (servicio con aviso donde se escribe el código). */
    fun begin(ctx: Context) {
        ctx.startForegroundService(Intent(ctx, AdbService::class.java).setAction("START"))
    }

    /** Reconecta si ya se vinculó antes y la depuración inalámbrica está activa. Llamar fuera del hilo principal. */
    fun reconnect(ctx: Context): Boolean {
        if (connected()) return true
        if (!File(ctx.filesDir, "adb_key.pk8").exists()) return false
        val r = findService(ctx, "_adb-tls-connect._tcp", 6000) ?: return false
        val ok = connect(ctx, r.first, r.second)
        if (ok) status = "Conectado ✅"
        return ok
    }

    /** Busca un servicio mDNS (vinculación o conexión de depuración inalámbrica). */
    fun findService(ctx: Context, type: String, timeoutMs: Long): Pair<String, Int>? {
        val nsd = ctx.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
        val latch = CountDownLatch(1)
        var res: Pair<String, Int>? = null
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String?) {}
            override fun onDiscoveryStopped(t: String?) {}
            override fun onStartDiscoveryFailed(t: String?, e: Int) { latch.countDown() }
            override fun onStopDiscoveryFailed(t: String?, e: Int) {}
            override fun onServiceLost(s: NsdServiceInfo?) {}
            override fun onServiceFound(s: NsdServiceInfo?) {
                val si = s ?: return
                nsd.resolveService(si, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(x: NsdServiceInfo?, e: Int) {}
                    override fun onServiceResolved(x: NsdServiceInfo?) {
                        val h = x?.host?.hostAddress
                        if (x != null && h != null) {
                            res = Pair(h, x.port)
                            latch.countDown()
                        }
                    }
                })
            }
        }
        nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l)
        latch.await(timeoutMs, TimeUnit.MILLISECONDS)
        try { nsd.stopServiceDiscovery(l) } catch (e: Exception) { }
        return res
    }
}

/** Asistente de vinculación: busca el cuadro "Vincular con código" y pide el código desde un aviso. */
class AdbService : Service() {
    private var host = ""
    private var pairPort = -1
    private var searching = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("adb", "Conexión ADB", NotificationManager.IMPORTANCE_HIGH))
        when (intent?.action) {
            "STOP" -> {
                stopSelf()
                return START_NOT_STICKY
            }
            "CODE" -> {
                startForeground(2, note("Vinculando…", "Un momento", false), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                val code = RemoteInput.getResultsFromIntent(intent!!)?.getCharSequence("code")?.toString()?.trim().orEmpty()
                doPair(code)
            }
            else -> {
                startForeground(
                    2,
                    note("Esperando el cuadro de vinculación", "En Ajustes → Depuración inalámbrica toca 'Vincular dispositivo con código de vinculación'.", false),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
                search()
            }
        }
        return START_NOT_STICKY
    }

    private fun search() {
        if (searching) return
        searching = true
        Adb.status = "Esperando el cuadro de vinculación…"
        Thread {
            val r = Adb.findService(this, "_adb-tls-pairing._tcp", 180_000)
            searching = false
            if (r != null) {
                host = r.first
                pairPort = r.second
                Adb.status = "Escribe el código en el aviso"
                update("Escribe el código de vinculación", "Toca 'Escribir código' y pon los 6 dígitos que ves en Ajustes.", true)
            } else {
                Adb.status = "No se encontró el cuadro de vinculación"
                update("No se encontró el cuadro", "Abre 'Vincular dispositivo con código de vinculación' y vuelve a empezar desde KilTeef.", false)
            }
        }.start()
    }

    private fun doPair(code: String) {
        if (pairPort < 0) {
            update("Aún no veo el cuadro", "Abre 'Vincular dispositivo con código de vinculación' en Ajustes.", false)
            return
        }
        Thread {
            val ok = Adb.pair(applicationContext, host, pairPort, code)
            if (!ok) {
                Adb.status = "Código incorrecto o vinculación fallida"
                update("No se pudo vincular", "Revisa el código y toca 'Escribir código' otra vez.", true)
            } else {
                Adb.status = "Vinculado. Conectando…"
                update("Vinculado ✅", "Conectando…", false)
                val r = Adb.findService(applicationContext, "_adb-tls-connect._tcp", 10_000)
                if (r != null && Adb.connect(applicationContext, r.first, r.second)) {
                    Adb.status = "Conectado ✅"
                    update("Conectado ✅", "KilTeef ya puede usar las funciones avanzadas.", false)
                } else {
                    Adb.status = "Vinculado, pero no pude conectar. Pulsa 'Reconectar'."
                    update("Vinculado", "Vuelve a KilTeef y pulsa 'Reconectar'.", false)
                }
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }.start()
    }

    private fun update(title: String, text: String, askCode: Boolean) {
        getSystemService(NotificationManager::class.java).notify(2, note(title, text, askCode))
    }

    private fun note(title: String, text: String, askCode: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).putExtra("tab", 5), PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(this, "adb")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setColor(0xFF42A5F5.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
        if (askCode) {
            val ri = RemoteInput.Builder("code").setLabel("Código de 6 dígitos").build()
            val pi = PendingIntent.getService(
                this, 1, Intent(this, AdbService::class.java).setAction("CODE"),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(
                Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_edit), "Escribir código", pi)
                    .addRemoteInput(ri).build()
            )
        }
        val stop = PendingIntent.getService(this, 2, Intent(this, AdbService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        b.addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Cancelar", stop).build())
        return b.build()
    }
}
