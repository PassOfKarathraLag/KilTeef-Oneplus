plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val withAdb = (findProperty("withAdb") as String?) != "false"

android {
    namespace = "com.kilteef.oneplus"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.kilteef.oneplus"
        minSdk = 34
        targetSdk = 35
        versionCode = 6
        versionName = "2.3"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("kilteef-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    sourceSets.getByName("main").java.srcDir(if (withAdb) "src/adbOn/java" else "src/adbOff/java")
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.compose.animation:animation")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    if (withAdb) {
        implementation("com.github.MuntashirAkon:libadb-android:1.0.1")
        implementation("org.conscrypt:conscrypt-android:2.5.2")
        implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
        implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    }
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
