#!/usr/bin/env bash
# Intenta compilar CON ADB integrado; si falla, compila SIN él para no quedarte sin APK.
if gradle assembleDebug -PwithAdb=true --stacktrace > build_adb.log 2>&1; then
  echo "✅ Compilado CON ADB integrado"
  exit 0
fi
echo "⚠️ Falló la compilación con ADB integrado. Errores principales:"
grep -E "^e: |What went wrong|Could not (resolve|find|get)|error:|Execution failed" -A4 build_adb.log | head -80
echo "↪ Compilando SIN ADB integrado..."
gradle assembleDebug -PwithAdb=false --stacktrace
